# Releasing Shiro

1. **Review first.** Have a psychologist or a suicide-prevention organisation read the crisis replies (Languages.kt), the curated replies (SupportReplies.kt) and the AI instructions (Brain.kt). Have native speakers check every language. Re-check the helpline numbers in Helplines.kt.
2. **Your own signing key** (keeps updates installable). On a PC with Java:
   `keytool -genkeypair -v -keystore shiro-release.jks -alias shiro -keyalg RSA -keysize 2048 -validity 10000`
   Then `base64 -w0 shiro-release.jks` and add four GitHub secrets (Settings > Secrets and variables > Actions): KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD. Keep the .jks file safe; losing it means users cannot update.
3. **Model mirror** (so downloads never break). Copy the model files to a place you control (for example your own Hugging Face repo or GitHub release) and change the URLs at the top of ModelStore.kt. The workflow's download-link check lists every URL's status.
4. **Licences.** Kannada, Tamil, Telugu and Bengali voices (Meta MMS) are CC-BY-NC 4.0: non-commercial only. Check the licence of each Piper voice. Confirm you may use the cat logo publicly.
5. **Store listing.** Publish PRIVACY.md as a web page, say clearly that Shiro is not medical care, and list the helplines.
