# Beta checklist (3 to 5 trusted people, different phones)

- [ ] Install, first launch, "Before we begin" screen, language choice
- [ ] Download finishes on Wi-Fi; also test an interrupted download (turn Wi-Fi off and on)
- [ ] Say "I feel lonely": instant warm reply. Say something unusual: the AI answers
- [ ] Say a crisis sentence: caring reply and helplines open; "Need help?" works on every screen
- [ ] Fill in My Safety Plan; trigger the crisis flow; the plan appears in the helplines list
- [ ] Hindi: switch language, screens change, voice speaks Hindi
- [ ] "Search for the capital of France" with internet on, then off
- [ ] Leave Shiro quiet for 3 minutes; lock the screen; get a phone call; check it recovers
- [ ] Settings > Send diagnostics works and contains no conversations
- [ ] Note phone model, memory, answer delay in seconds, anything that stopped by itself
