# Shiro - Privacy (draft, have it reviewed before publishing)

**What stays on the phone:** your voice, your conversations, your mood, journal, gratitude notes, goals, safety plan and trusted contacts. Shiro has no account, no server and no analytics.

**What can leave the phone:**
- Model downloads (once): from Hugging Face and GitHub.
- Internet search, only when you ask Shiro to search and have allowed it: the words of the search question go to DuckDuckGo and Wikipedia. Conversations about feelings are never sent.
- If you choose Phone voice in Settings, the phone's own speech service (usually Google) may process your audio. The default Offline voices keep audio on the phone.
- "Send diagnostics" creates a short technical report (phone model, memory, errors). It contains no conversations. Nothing is sent unless you press Share.

**Deleting data:** Settings > Privacy & Data > Delete my saved data. Uninstalling Shiro removes everything.

**Not medical care:** Shiro is an AI companion, not a doctor or therapist, and cannot replace a real person. In an emergency contact local emergency services or a helpline.
