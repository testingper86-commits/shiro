package com.shiro.companion

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** A fixed list of risky and harmless sentences per language. Runs on every build so crisis detection cannot silently break. */
class CrisisPhrasesTest {
    private val risky = mapOf(
        "en" to listOf("I want to die", "I'm thinking about suicide", "I can\u2019t go on", "I don't want to be here anymore", "I wish I was dead",
            "I want to end it all", "there is no point in living", "I'm going to kill myself", "life isn't worth living", "I want to hurt myself",
            "I'm tired of living", "everyone would be better off without me"),
        "hi" to listOf("मैं मरना चाहता हूँ", "मुझे जीने का मन नहीं है", "मैं आत्महत्या करना चाहता हूँ", "मैं खुद को खत्म कर लूँगा"),
        "es" to listOf("quiero morir", "no quiero vivir más", "pienso en suicidarme"),
        "fr" to listOf("je veux mourir", "je pense au suicide", "je ne veux plus vivre"),
        "it" to listOf("voglio morire", "penso al suicidio", "non voglio più vivere"),
        "pt" to listOf("quero morrer", "penso em suicídio", "não quero mais viver"),
        "de" to listOf("ich will sterben", "ich denke an suizid", "ich will mich umbringen"),
        "ru" to listOf("хочу умереть", "думаю о самоубийстве", "не хочу жить"),
        "ar" to listOf("أريد أن أموت", "أفكر في الانتحار", "لا أريد أن أعيش"),
        "tr" to listOf("ölmek istiyorum", "intihar etmeyi düşünüyorum", "yaşamak istemiyorum"),
        "vi" to listOf("tôi muốn chết", "tôi nghĩ đến tự tử", "tôi không muốn sống"),
        "id" to listOf("aku ingin mati", "aku berpikir untuk bunuh diri", "aku tidak ingin hidup"),
        "pl" to listOf("chcę umrzeć", "myślę o samobójstwie", "nie chcę żyć"),
        "ur" to listOf("میں مرنا چاہتا ہوں", "مجھے خودکشی کا خیال آتا ہے", "میں جینا نہیں چاہتا"),
        "kn" to listOf("ನಾನು ಸಾಯಲು ಬಯಸುತ್ತೇನೆ", "ಆತ್ಮಹತ್ಯೆ ಮಾಡಿಕೊಳ್ಳಬೇಕು"),
        "ta" to listOf("நான் சாக விரும்புகிறேன்", "தற்கொலை செய்ய நினைக்கிறேன்"),
        "te" to listOf("నేను చనిపోవాలి", "ఆత్మహత్య చేసుకోవాలని ఉంది"),
        "bn" to listOf("আমি মরতে চাই", "আমি আত্মহত্যা করতে চাই")
    )
    private val harmless = mapOf(
        "en" to listOf("I had a long day at work", "I'm tired after work", "this heat is killing me", "what is the weather today"),
        "hi" to listOf("आज मौसम अच्छा है", "मैं थक गया हूँ", "मुझे भूख लगी है"),
        "es" to listOf("tengo hambre", "hoy hace calor"), "fr" to listOf("j'ai faim", "il fait chaud"),
        "it" to listOf("ho fame", "oggi fa caldo"), "pt" to listOf("estou com fome", "hoje está quente"),
        "de" to listOf("ich habe hunger", "heute ist es warm"), "ru" to listOf("я голоден", "сегодня тепло"),
        "ar" to listOf("أنا جائع", "الطقس جميل اليوم"), "tr" to listOf("acıktım", "bugün hava sıcak"),
        "vi" to listOf("tôi đói", "hôm nay trời nóng"), "id" to listOf("aku lapar", "hari ini panas"),
        "pl" to listOf("jestem głodny", "dziś jest ciepło"), "ur" to listOf("مجھے بھوک لگی ہے", "آج موسم اچھا ہے"),
        "kn" to listOf("ನನಗೆ ಹಸಿವಾಗಿದೆ"), "ta" to listOf("எனக்கு பசிக்கிறது"), "te" to listOf("నాకు ఆకలిగా ఉంది"), "bn" to listOf("আমার ক্ষুধা পেয়েছে")
    )

    @Test fun riskySentencesAreDetected() {
        for ((code, list) in risky) for (s in list)
            assertTrue("missed in $code: $s", Safety.isCrisis(s, Languages.byCode(code)))
    }

    @Test fun harmlessSentencesAreNotFlagged() {
        for ((code, list) in harmless) for (s in list)
            assertFalse("false alarm in $code: $s", Safety.isCrisis(s, Languages.byCode(code)))
    }
}
