package com.shiro.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WebSearchParseTest {
    @Test fun duckDuckGoHtml() {
        val html = """
          <div class="result results_links">
            <a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=x">Paris - <b>Capital</b> of France</a>
            <a class="result__snippet" href="//duckduckgo.com/l/?uddg=x">Paris is the capital &amp; largest city of France.</a>
          </div>
          <div class="result results_links">
            <a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=y">Second result</a>
            <a class="result__snippet" href="//duckduckgo.com/l/?uddg=y">Another snippet &#x27;quoted&#x27;.</a>
          </div>"""
        val r = WebSearch.parseDuckDuckGo(html)
        assertEquals(2, r.size)
        assertEquals("Paris - Capital of France", r[0].title)
        assertEquals("Paris is the capital & largest city of France.", r[0].snippet)
        assertEquals("Another snippet 'quoted'.", r[1].snippet)
    }

    @Test fun emptyOrBlockedPageGivesNoResults() {
        assertTrue(WebSearch.parseDuckDuckGo("<html><body>anomaly</body></html>").isEmpty())
    }

    @Test fun wikipediaJson() {
        val json = """{"query":{"pages":{"1":{"title":"B","index":2,"extract":"Second."},
            "2":{"title":"A","index":1,"extract":"First."}}}}"""
        val r = WebSearch.parseWikipedia(json)
        assertEquals(listOf("A", "B"), r.map { it.title })
        assertTrue(WebSearch.parseWikipedia("{}").isEmpty())
    }

    @Test fun promptFormatting() {
        val s = WebSearch.formatForPrompt(listOf(WebSearch.Result("T", "S")))
        assertEquals("[1] T: S", s)
    }
}
