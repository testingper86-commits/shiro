package com.shiro.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HelplinesTest {
    @Test fun tableIsLargeAndConsistent() {
        assertTrue(Helplines.all.size >= 190)
        assertEquals(Helplines.all.size, Helplines.all.map { it.iso }.toSet().size)
        for (h in Helplines.all) {
            assertTrue("no dial for ${h.iso}", h.dial.isNotEmpty())
            assertTrue("bad iso ${h.iso}", h.iso.length == 2)
        }
    }

    @Test fun spotChecks() {
        assertEquals("988", Helplines.forIso("us")?.display)
        assertEquals("14416", Helplines.forIso("IN")?.dial)
        assertEquals("*4141", Helplines.forIso("CL")?.dial)
        assertNotNull(Helplines.forIso("GB"))
    }
}
