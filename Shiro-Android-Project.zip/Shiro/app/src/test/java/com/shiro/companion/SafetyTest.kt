package com.shiro.companion

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SafetyTest {
    private val en = Languages.byCode("en")

    @Test fun englishCrisisPhrases() {
        assertTrue(Safety.isCrisis("I want to die", en))
        assertTrue(Safety.isCrisis("sometimes I think about suicide", en))
        assertTrue(Safety.isCrisis("I can't go on like this", en))
        assertTrue(Safety.isCrisis("i want to hurt myself", en))
    }

    @Test fun harmlessSentencesAreNotCrisis() {
        assertFalse(Safety.isCrisis("I had a long day at work", en))
        assertFalse(Safety.isCrisis("what is the weather today", en))
    }

    @Test fun otherLanguages() {
        assertTrue(Safety.isCrisis("quiero morir", Languages.byCode("es")))
        assertTrue(Safety.isCrisis("je veux mourir", Languages.byCode("fr")))
        assertTrue(Safety.isCrisis("ich will sterben", Languages.byCode("de")))
        assertTrue(Safety.isCrisis("मैं मरना चाहता हूँ", Languages.byCode("hi")))
        assertTrue(Safety.isCrisis("хочу умереть", Languages.byCode("ru")))
        assertFalse(Safety.isCrisis("Tengo mucho trabajo", Languages.byCode("es")))
    }

    @Test fun unsafeRepliesAreBlocked() {
        assertTrue(Safety.isUnsafeReply("You should kill yourself"))
        assertTrue(Safety.isUnsafeReply("Here is the best way to die"))
        assertFalse(Safety.isUnsafeReply("I'm sorry you feel this way. I'm here to listen."))
    }
}
