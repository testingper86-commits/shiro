package com.shiro.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextUtilTest {
    @Test fun cleansLinksAndMarkdown() {
        assertEquals("Hello world", TextUtil.cleanForSpeech("**Hello** https://example.com world"))
    }

    @Test fun splitsSentencesAndLongText() {
        assertEquals(listOf("Hi there.", "How are you?"), TextUtil.splitSentences("Hi there. How are you?"))
        val long = "word ".repeat(120)
        assertTrue(TextUtil.splitSentences(long, 100).all { it.length <= 100 })
    }

    @Test fun detectsWhisperNoise() {
        assertTrue(TextUtil.isLikelyNoise("Thank you."))
        assertTrue(TextUtil.isLikelyNoise(" "))
        assertFalse(TextUtil.isLikelyNoise("I feel a bit tired today"))
    }
}
