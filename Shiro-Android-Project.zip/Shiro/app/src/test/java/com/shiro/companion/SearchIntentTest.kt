package com.shiro.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SearchIntentTest {
    @Test fun explicitSearch() {
        assertEquals("capital of France", SearchIntent.extract("Search the internet for the capital of France", "en"))
        assertEquals("best pizza in rome", SearchIntent.extract("can you google best pizza in rome please", "en"))
        assertEquals("how tall is mount everest", SearchIntent.extract("please look up how tall is mount everest", "en"))
    }

    @Test fun liveInfo() {
        assertEquals("what's the weather in Paris today", SearchIntent.extract("what's the weather in Paris today", "en"))
        assertEquals("what's the news today", SearchIntent.extract("what's the news today", "en"))
    }

    @Test fun feelingsAreNeverSearched() {
        assertNull(SearchIntent.extract("I look up to my father", "en"))
        assertNull(SearchIntent.extract("I feel like I am searching for meaning", "en"))
        assertNull(SearchIntent.extract("I can't find peace anymore", "en"))
        assertNull(SearchIntent.extract("I am stressed about the news and can't sleep", "en"))
        assertNull(SearchIntent.extract("I'm so worried about the weather tomorrow", "en"))
        assertNull(SearchIntent.extract("I had a bad day at work", "en"))
    }

    @Test fun otherLanguages() {
        assertEquals("पेरिस की राजधानी", SearchIntent.extract("पेरिस की राजधानी सर्च करो", "hi"))
        assertEquals("el precio del dólar hoy", SearchIntent.extract("Busca el precio del dólar hoy", "es"))
        assertEquals("la météo à Lyon", SearchIntent.extract("Cherche la météo à Lyon", "fr"))
        assertNull(SearchIntent.extract("Estoy triste por las noticias", "es"))
        assertNull(SearchIntent.extract("मैं सुकून खोज रहा हूँ", "hi"))
    }

    @Test fun languagesWithoutOwnPatternsFallBackToEnglish() {
        assertEquals("capital of France", SearchIntent.extract("search for capital of France", "kn"))
    }

    @Test fun explicitVerbsDoNotOverridePersonalLanguage() {
        assertNull(SearchIntent.extract("Search for why I feel this way?", "en"))
        assertNull(SearchIntent.extract("Busca por qué me siento así", "es"))
        assertNull(SearchIntent.extract("Busca why I feel this way", "es"))
        assertNull(SearchIntent.extract("मेरी चिंता के बारे में सर्च करो", "hi"))
    }

    @Test fun emptySearchCommandsDoNotBecomeQueries() {
        assertNull(SearchIntent.extract("Search for...", "en"))
        assertNull(SearchIntent.extract("please look up", "en"))
        assertEquals("π", SearchIntent.extract("search for π", "en"))
    }
}
