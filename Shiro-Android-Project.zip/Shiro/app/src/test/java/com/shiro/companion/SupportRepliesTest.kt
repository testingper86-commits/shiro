package com.shiro.companion

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SupportRepliesTest {
    @Test fun clearFeelingsGetAWarmReply() {
        for (s in listOf("I feel so lonely", "I'm really stressed", "I can't sleep", "I am sad today", "my brother passed away", "I feel hopeless"))
            assertNotNull("no reply for: $s", SupportReplies.match(s, "en"))
        assertNotNull(SupportReplies.match("मैं बहुत अकेला हूँ", "hi"))
        assertNotNull(SupportReplies.match("मुझे बहुत तनाव है", "hi"))
    }

    @Test fun everythingElseGoesToTheAi() {
        assertNull(SupportReplies.match("why is the sky blue?", "en"))
        assertNull(SupportReplies.match("I am not sad, just curious", "en"))
        assertNull(SupportReplies.match("tell me a story", "en"))
        assertNull(SupportReplies.match("I feel lonely", "kn"))     // other languages: the AI answers
        assertNull(SupportReplies.match("I have been stressed about my exams for a long time and I really do not know what to do now", "en"))
    }

    @Test fun repliesAreWarmAndShort() {
        val r = SupportReplies.match("I feel sad", "en")!!
        assertTrue(r.length < 300 && r.endsWith("?") || r.endsWith("."))
    }
}
