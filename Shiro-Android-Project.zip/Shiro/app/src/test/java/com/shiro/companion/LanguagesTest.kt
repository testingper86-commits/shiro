package com.shiro.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LanguagesTest {
    @Test fun everyLanguageIsComplete() {
        val all = Languages.all
        assertEquals(all.size, all.map { it.code }.toSet().size)
        for (l in all) {
            for (s in listOf(l.label, l.greeting, l.crisisReply, l.tap, l.loading, l.listening, l.thinking,
                l.speaking, l.searching, l.noInternet, l.searchFailed, l.searchOff)) {
                assertTrue("empty text in ${l.code}", s.isNotBlank())
            }
            when (val v = l.voice) {
                is VoiceSpec.Piper -> assertTrue(v.pack.startsWith("vits-piper-"))
                is VoiceSpec.Mms -> assertEquals(3, v.iso3.length)
            }
        }
    }

    @Test fun unknownCodeFallsBackToEnglish() {
        assertEquals("en", Languages.byCode("xx").code)
        assertEquals("en", Languages.byCode(null).code)
    }
}
