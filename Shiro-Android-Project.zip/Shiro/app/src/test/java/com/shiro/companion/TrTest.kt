package com.shiro.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrTest {
    private val placeholders = Regex("""%\d*[ds]""")

    @Test fun hindiEntriesKeepTheSamePlaceholders() {
        for ((en, hi) in Tr.hindiEntries()) {
            assertTrue("empty Hindi for: $en", hi.isNotBlank())
            assertEquals("placeholder mismatch for: $en",
                placeholders.findAll(en).map { it.value }.sorted().toList(),
                placeholders.findAll(hi).map { it.value }.sorted().toList())
        }
    }

    @Test fun switchesBetweenEnglishAndHindi() {
        Tr.hindi = false
        assertEquals("Settings", Tr.t("Settings"))
        Tr.hindi = true
        assertEquals("सेटिंग्स", Tr.t("Settings"))
        assertEquals("Unknown text", Tr.t("Unknown text"))
        assertTrue(Tr.f("Saved to %s", "डायरी").contains("डायरी"))
        Tr.hindi = false
        assertEquals("Saved to Journal", Tr.f("Saved to %s", "Journal"))
    }
}
