package com.shiro.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechTagsTest {
    @Test fun everyLanguageHasATag() {
        for (l in Languages.all) assertTrue("no tag for ${l.code}", SpeechTags.forLang(l.code).contains("-"))
    }

    @Test fun indianLanguagesUseIndianLocales() {
        assertEquals("hi-IN", SpeechTags.forLang("hi"))
        assertEquals("kn-IN", SpeechTags.forLang("kn"))
        assertEquals("ta-IN", SpeechTags.forLang("ta"))
    }
}
