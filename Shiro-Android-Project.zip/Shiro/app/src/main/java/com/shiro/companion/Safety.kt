package com.shiro.companion

object Safety {
    private val crisis = Regex(
        """\b(kill myself|killing myself|end my life|ending my life|end it all|want to die|wanna die|""" +
            """suicid\w*|take my own life|(don'?t|do not) want to (live|be alive|exist)|no reason to live|""" +
            """better off dead|better off without me|hurt myself|harm myself|self[- ]?harm|cut myself|""" +
            """not worth living|can'?t go on|give up on life|want to disappear|give up on everything)\b""",
        RegexOption.IGNORE_CASE
    )

    /** Things Shiro must never say, even if the language model produces them (English wording). */
    private val unsafeReply = Regex(
        """\b((how|ways) to (kill|hurt|harm|hang|cut) (yourself|myself)|you should (kill|hurt|harm|end) yourself|""" +
            """overdose on|hang yourself|slit your|jump off (a|the) (bridge|building|roof)|best way to die|""" +
            """painless (way|death)|suicide method)\b""",
        RegexOption.IGNORE_CASE
    )

    /** English patterns are always checked (people mix languages), plus the selected language. */
    fun isCrisis(text: String, lang: Lang): Boolean =
        crisis.containsMatchIn(text) || lang.crisisRegex.containsMatchIn(text)

    fun isUnsafeReply(text: String): Boolean = unsafeReply.containsMatchIn(text)

    const val CRISIS_REPLY =
        "I'm really glad you told me, and I'm worried about you. You deserve support from a real person right now. " +
            "Please reach out to someone you trust, or call a helpline. Tap the red help button on your screen. " +
            "If you think you might act on these thoughts, please call your local emergency number right now. " +
            "I'm still here and I'll keep listening, but please contact someone too."
}
