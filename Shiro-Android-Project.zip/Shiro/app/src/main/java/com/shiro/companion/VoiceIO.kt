package com.shiro.companion

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** The phone's speech service is missing, offline data is missing, or it failed to start. */
class SpeechUnavailable(message: String) : Exception(message)

/** Anything that can listen: returns the text, "" for noise or something not understood, null when nobody spoke. */
interface VoiceIn {
    fun listen(cancelled: () -> Boolean, onSpeechEnd: () -> Unit): String?
}

interface VoiceOut {
    fun speak(text: String, speed: Float, cancelled: () -> Boolean)
    fun stop()
}

object SpeechTags {
    /** BCP-47 tag the phone's recognizer and voice use for each of Shiro's languages. */
    fun forLang(code: String): String = when (code) {
        "en" -> Locale.getDefault().let { if (it.language == "en" && it.country.isNotEmpty()) it.toLanguageTag() else "en-US" }
        "hi" -> "hi-IN"; "kn" -> "kn-IN"; "ta" -> "ta-IN"; "te" -> "te-IN"; "bn" -> "bn-IN"; "ur" -> "ur-PK"
        "es" -> "es-ES"; "fr" -> "fr-FR"; "it" -> "it-IT"; "pt" -> "pt-BR"; "de" -> "de-DE"; "ru" -> "ru-RU"
        "ar" -> "ar-SA"; "tr" -> "tr-TR"; "vi" -> "vi-VN"; "id" -> "id-ID"; "pl" -> "pl-PL"
        else -> "en-US"
    }
}

/** Open-source path: microphone + Whisper on the phone. */
class OfflineIn(private val mic: MicListener, private val ears: Ears) : VoiceIn {
    override fun listen(cancelled: () -> Boolean, onSpeechEnd: () -> Unit): String? {
        val audio = mic.capture(cancelled) ?: return null
        onSpeechEnd()
        if (audio.isEmpty()) return ""
        return ears.transcribe(audio)
    }
}

/** Fast path: the phone's own speech recognition (Android SpeechRecognizer), no model to download. */
class SystemListener(ctx: Context, private val lang: Lang) : VoiceIn {
    private val app = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    @Volatile var onLevel: ((Float) -> Unit)? = null

    private class Out(val text: String?, val error: Int)

    private fun once(cancelled: () -> Boolean, onSpeechEnd: () -> Unit): Out {
        val latch = CountDownLatch(1)
        val text = AtomicReference<String?>(null)
        val err = AtomicInteger(0)
        val recRef = AtomicReference<SpeechRecognizer?>(null)
        main.post {
            try {
                val rec = SpeechRecognizer.createSpeechRecognizer(app)
                recRef.set(rec)
                rec.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) { onLevel?.invoke(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { onSpeechEnd() }
                    override fun onError(error: Int) { err.set(error); latch.countDown() }
                    override fun onResults(results: Bundle?) {
                        text.set(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
                        latch.countDown()
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                rec.startListening(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, SpeechTags.forLang(lang.code))
                        .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                        .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                        .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
                        .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
                )
            } catch (t: Throwable) {
                err.set(SpeechRecognizer.ERROR_CLIENT); latch.countDown()
            }
        }
        var wasCancelled = false
        while (!latch.await(150, TimeUnit.MILLISECONDS)) {
            if (cancelled()) { wasCancelled = true; break }
        }
        main.post { try { recRef.get()?.cancel(); recRef.get()?.destroy() } catch (_: Throwable) {} }
        return if (wasCancelled) Out(null, -1) else Out(text.get(), err.get())
    }

    override fun listen(cancelled: () -> Boolean, onSpeechEnd: () -> Unit): String? {
        var attempts = 0
        while (true) {
            val o = once(cancelled, onSpeechEnd)
            if (o.error == -1 || cancelled()) return null
            when (o.error) {
                0 -> return o.text ?: ""
                SpeechRecognizer.ERROR_NO_MATCH -> return ""            // heard something, understood nothing
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> return null    // nobody spoke
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                    if (++attempts >= 3) throw SpeechUnavailable(Tr.t("Your phone cannot recognise speech right now. Check the Google app or Speech Services, or switch to Offline voices in Settings."))
                    Thread.sleep(500)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    throw SpeechUnavailable(Tr.t("Shiro needs the microphone permission to hear you. You can allow it in the phone's app settings."))
                else -> throw SpeechUnavailable(Tr.t("Phone voice needs the internet or an offline language pack for this language. Connect to the internet, or switch to Offline voices in Settings."))
            }
        }
    }
}

/** Fast path: the phone's own text-to-speech engine, no voice to download. */
class SystemSpeaker(ctx: Context) : VoiceOut, TextToSpeech.OnInitListener {
    private val initLatch = CountDownLatch(1)
    @Volatile private var initOk = false
    private var tts: TextToSpeech? = null
    @Volatile private var current: CountDownLatch? = null
    @Volatile private var halt = false

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { current?.countDown() }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) { current?.countDown() }
        override fun onError(utteranceId: String?, errorCode: Int) { current?.countDown() }
    }

    init { tts = TextToSpeech(ctx.applicationContext, this) }

    override fun onInit(status: Int) {
        initOk = status == TextToSpeech.SUCCESS
        initLatch.countDown()
    }

    /** Waits for the engine and selects the language. Throws SpeechUnavailable with a helpful message. */
    fun use(lang: Lang) {
        if (!initLatch.await(8, TimeUnit.SECONDS) || !initOk) {
            throw SpeechUnavailable(Tr.t("Your phone's voice engine did not start. Check its settings, or switch to Offline voices in Settings."))
        }
        val t = tts ?: throw SpeechUnavailable(Tr.t("Your phone's voice engine did not start. Check its settings, or switch to Offline voices in Settings."))
        t.setOnUtteranceProgressListener(listener)
        val r = t.setLanguage(Locale.forLanguageTag(SpeechTags.forLang(lang.code)))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            throw SpeechUnavailable(Tr.t("Your phone has no voice for this language. Install it in the phone's text-to-speech settings, or switch to Offline voices in Settings."))
        }
    }

    override fun speak(text: String, speed: Float, cancelled: () -> Boolean) {
        val t = tts ?: return
        halt = false
        t.setSpeechRate(speed)
        for (chunk in TextUtil.splitSentences(TextUtil.cleanForSpeech(text))) {
            if (cancelled() || halt) return
            val latch = CountDownLatch(1)
            current = latch
            val id = "shiro-" + System.nanoTime()
            if (t.speak(chunk, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) continue
            val deadline = System.currentTimeMillis() + 40_000
            while (!latch.await(100, TimeUnit.MILLISECONDS)) {
                if (cancelled() || halt || System.currentTimeMillis() > deadline) { try { t.stop() } catch (_: Throwable) {}; return }
            }
        }
    }

    override fun stop() {
        halt = true
        try { tts?.stop() } catch (_: Throwable) {}
        current?.countDown()
    }

    fun close() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Throwable) {}
        tts = null
    }
}
