package com.shiro.companion

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/** Calming sounds synthesised on the phone (no audio files): rain, ocean waves, wind. */
class NoiseGenerator(private val kind: Kind) {
    enum class Kind(val label: String) { RAIN("Rain"), OCEAN("Ocean waves"), WIND("Soft wind") }

    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread {
            val rate = 22050
            val buf = ShortArray(rate / 5)
            val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(minBuf, buf.size * 2 * 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            val rnd = Random(System.nanoTime())
            var lp = 0.0; var brown = 0.0; var t = 0L; var fade = 0.0
            try {
                track.play()
                while (running) {
                    for (i in buf.indices) {
                        val white = rnd.nextDouble() * 2 - 1
                        val sec = t / rate.toDouble()
                        val s = when (kind) {
                            Kind.RAIN -> { lp += (white - lp) * 0.12; (white - lp) * 0.45 }
                            Kind.OCEAN -> { brown = (brown + 0.02 * white) / 1.02; brown * 3.2 * (0.55 + 0.45 * sin(2 * PI * 0.09 * sec)) }
                            Kind.WIND -> { lp += (white - lp) * (0.02 + 0.03 * (0.5 + 0.5 * sin(2 * PI * 0.06 * sec))); lp * 3.5 }
                        }
                        fade = minOf(1.0, fade + 1.0 / rate)           // 1 second fade-in
                        buf[i] = (s.coerceIn(-1.0, 1.0) * fade * 0.55 * 32767).toInt().toShort()
                        t++
                    }
                    track.write(buf, 0, buf.size)
                }
            } finally {
                try { track.stop() } catch (_: Throwable) {}
                track.release()
            }
        }.also { it.start() }
    }

    fun stop() { running = false }
}
