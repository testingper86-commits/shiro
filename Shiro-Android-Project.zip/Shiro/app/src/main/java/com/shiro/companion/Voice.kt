package com.shiro.companion

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private fun threads(): Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 4)

/** Speech-to-text with multilingual Whisper (sherpa-onnx). */
class Ears(ctx: Context, lang: Lang) {
    private val recognizer: OfflineRecognizer

    init {
        val dir = ModelStore.whisperDir(ctx)
        val onnx = dir.listFiles { f -> f.name.endsWith(".onnx") }?.toList().orEmpty()
        fun pick(word: String): File {
            val l = onnx.filter { it.name.contains(word) }
            return l.firstOrNull { it.name.contains("int8") } ?: l.first()
        }
        val tokens = dir.listFiles { f -> f.name.endsWith("tokens.txt") }!!.first()
        val config = OfflineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
            modelConfig = OfflineModelConfig(
                whisper = OfflineWhisperModelConfig(
                    encoder = pick("encoder").absolutePath,
                    decoder = pick("decoder").absolutePath,
                    language = lang.code,
                    task = "transcribe"
                ),
                tokens = tokens.absolutePath,
                numThreads = threads(),
                debug = false,
                provider = "cpu",
                modelType = "whisper"
            )
        )
        recognizer = OfflineRecognizer(assetManager = null, config = config)
    }

    fun transcribe(samples: FloatArray): String {
        val stream = recognizer.createStream()
        try {
            stream.acceptWaveform(samples, 16000)
            recognizer.decode(stream)
            return recognizer.getResult(stream).text.replace(Regex("""\[.*?]|\(.*?\)"""), "").trim()
        } finally {
            stream.release()
        }
    }

    fun close() { try { recognizer.release() } catch (_: Throwable) {} }
}

/** Text-to-speech with an open-source VITS voice (Piper or MMS) through sherpa-onnx. */
class Mouth(ctx: Context, private val lang: Lang) {
    private val tts: OfflineTts
    @Volatile private var track: AudioTrack? = null
    @Volatile private var halt = false

    init {
        val dir = ModelStore.voiceDir(ctx, lang.voice)
        val vits = when (lang.voice) {
            is VoiceSpec.Piper -> {
                val onnx = dir.listFiles { f -> f.name.endsWith(".onnx") }!!.first()
                OfflineTtsVitsModelConfig(
                    model = onnx.absolutePath,
                    tokens = File(dir, "tokens.txt").absolutePath,
                    dataDir = File(dir, "espeak-ng-data").absolutePath
                )
            }
            is VoiceSpec.Mms -> OfflineTtsVitsModelConfig(
                model = File(dir, "model.onnx").absolutePath,
                tokens = File(dir, "tokens.txt").absolutePath
            )
        }
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(vits = vits, numThreads = threads(), debug = false, provider = "cpu")
        )
        tts = OfflineTts(assetManager = null, config = config)
    }

    /** Interrupts playback immediately. */
    fun stop() {
        halt = true
        try { track?.stop() } catch (_: Throwable) {}
    }

    /** Blocking: speaks the text chunk by chunk; returns early when [cancelled] becomes true. */
    fun speak(text: String, speed: Float = 1.0f, cancelled: () -> Boolean) {
        halt = false
        for (chunk in TextUtil.splitSentences(TextUtil.cleanForSpeech(text))) {
            if (cancelled() || halt) return
            val audio = try {
                tts.generate(text = chunk, sid = 0, speed = speed)
            } catch (_: Throwable) {
                continue // skip a chunk the voice cannot pronounce
            }
            if (cancelled() || halt) return
            play(audio.samples, audio.sampleRate, cancelled)
        }
    }

    private fun play(samples: FloatArray, sampleRate: Int, cancelled: () -> Boolean) {
        if (samples.isEmpty()) return
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuf, samples.size * 4))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        try {
            t.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
            t.play()
            val deadline = System.currentTimeMillis() + samples.size * 1000L / sampleRate + 2500
            while (!cancelled() && !halt && t.playbackHeadPosition < samples.size &&
                System.currentTimeMillis() < deadline
            ) Thread.sleep(30)
        } finally {
            try { t.stop() } catch (_: Throwable) {}
            t.release()
            track = null
        }
    }

    fun close() { try { tts.release() } catch (_: Throwable) {} }
}

/** Microphone capture with simple energy-based end-of-speech detection. */
class MicListener {
    private val sr = 16000
    /** Called for every 100 ms of audio with a 0..1 loudness (drives the waveform). */
    @Volatile var onLevel: ((Float) -> Unit)? = null

    /** Returns the spoken audio, or null if nothing (or only noise) was heard. */
    fun capture(cancelled: () -> Boolean): FloatArray? {
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, sr,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, sr)
            )
        } catch (_: Throwable) { return null }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return null }
        val frames = ArrayList<ShortArray>()
        var voiced = 0
        try {
            rec.startRecording()
            val frameSize = sr / 10 // 100 ms
            var noise = 0.0
            var calibrated = 0
            var threshold = 0.02
            var speechStarted = false
            var silentFrames = 0
            var totalFrames = 0
            while (!cancelled()) {
                val buf = ShortArray(frameSize)
                var read = 0
                while (read < frameSize && !cancelled()) {
                    val n = rec.read(buf, read, frameSize - read)
                    if (n <= 0) return null
                    read += n
                }
                if (cancelled()) return null
                totalFrames++
                val level = rms(buf)
                onLevel?.invoke(min(1.0, level * 9).toFloat())
                if (calibrated < 5) {
                    noise += level; calibrated++
                    if (calibrated == 5) threshold = max(0.02, noise / 5 * 3.0)
                    continue
                }
                frames.add(buf)
                if (level > threshold) {
                    voiced++
                    if (!speechStarted) {
                        speechStarted = true
                        while (frames.size > 4) frames.removeAt(0) // short lead-in only
                    }
                    silentFrames = 0
                } else if (speechStarted) {
                    if (++silentFrames >= 12) break // 1.2 s of silence ends the sentence
                } else if (frames.size > 6) {
                    frames.removeAt(0)
                }
                if (!speechStarted && totalFrames > 150) return null // 15 s of nothing
                if (speechStarted && frames.size > 300) break // 30 s max
            }
            if (!speechStarted || cancelled() || voiced < 4) return null // too short = noise
        } finally {
            try { rec.stop() } catch (_: Throwable) {}
            rec.release()
        }
        val total = frames.sumOf { it.size }
        val out = FloatArray(total)
        var i = 0
        for (f in frames) for (s in f) out[i++] = s / 32768f
        return out
    }

    private fun rms(b: ShortArray): Double {
        var sum = 0.0
        for (s in b) sum += s.toDouble() * s
        return min(1.0, sqrt(sum / b.size) / 32768.0)
    }
}
