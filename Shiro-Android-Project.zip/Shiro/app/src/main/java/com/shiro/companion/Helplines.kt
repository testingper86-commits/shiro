package com.shiro.companion

import android.content.Context
import android.telephony.TelephonyManager
import java.util.Locale

data class Helpline(val iso: String, val country: String, val display: String, val dial: String, val note: String = "")

/**
 * National crisis / suicide-prevention lines by country (ISO 3166-1 alpha-2).
 * Source: Wikipedia "List of suicide crisis lines" (retrieved 2026-10-22), which cites each national service.
 * This list is bundled offline and will go out of date: re-check it before every release.
 * Format per line: ISO|Country|Number as shown|Number to dial (optional)|Note (optional)
 */
object Helplines {
    private const val RAW = """
DZ|Algeria|0560 00 13 38
BJ|Benin|7344
BW|Botswana|75 527 590
BI|Burundi|69 77 63 67
CM|Cameroon|242 136 136
EG|Egypt|16328
SZ|Eswatini|2404 3160
ET|Ethiopia|8335
GH|Ghana|024 447 1279
CI|Ivory Coast|143
KE|Kenya|0722 178 177
LR|Liberia|6534308
ML|Mali|8000 1115
MA|Morocco|0522 25 25 25
MW|Malawi|0999 399 765 (Airtel)|0999399765|TNM network: 885 400 502
MU|Mauritius|800 93 93
NA|Namibia|116
NG|Nigeria|0800 078 7746
RW|Rwanda|8015
ST|São Tomé and Príncipe|222 2222
SN|Senegal|33 889 38 00
SC|Seychelles|432 3535
SL|Sierra Leone|078 522 787
ZA|South Africa|0800 567 567
SS|South Sudan|778
SD|Sudan|011 555 253
TZ|Tanzania|199
TG|Togo|2221 1234
TN|Tunisia|8010 3666
UG|Uganda|0800 21 21 21
ZM|Zambia|096 026 4040
ZW|Zimbabwe|029 226 5000
RE|Réunion|3114
YT|Mayotte|3114
AI|Anguilla|(264) 772-7233
AG|Antigua and Barbuda|(268) 463-5555
AW|Aruba|131
BS|Bahamas|(242) 328-0922
BB|Barbados|(246) 536-4500
BM|Bermuda|(441) 239-1111
KY|Cayman Islands|1-800-534-6463||Limited hours (weekday evenings)
CU|Cuba|103
CW|Curaçao|918
DM|Dominica|767-317-3030
DO|Dominican Republic|809-200-1400
GD|Grenada|(473) 440-6849
GP|Guadeloupe|3114
HT|Haiti|116
JM|Jamaica|(888) 639-5433
MQ|Martinique|3114
PR|Puerto Rico|988
BL|Saint Barthélemy|3114
KN|Saint Kitts and Nevis|(869) 465-5000
LC|Saint Lucia|203
MF|Saint Martin|3114
VC|Saint Vincent and the Grenadines|(784) 456-1044
SX|Sint Maarten|721 585-5556
TT|Trinidad and Tobago|800-5588
VI|US Virgin Islands|988
CR|Costa Rica|800 273 7869
SV|El Salvador|126
GT|Guatemala|1503
HN|Honduras|150
NI|Nicaragua|2222 4830||Weekdays 8am-5pm
PA|Panama|147
CA|Canada|988
GL|Greenland|801180
MX|Mexico|55-5259-8121
US|United States|988
PM|Saint Pierre and Miquelon|3114
AR|Argentina|0800 999 0091
BO|Bolivia|800 11 3040
BR|Brazil|188
CL|Chile|*4141
CO|Colombia|106
EC|Ecuador|171 (press 6)|171|Press 6 after connecting
FK|Falkland Islands|51515
GF|French Guiana|3114
GY|Guyana|915
PY|Paraguay|155
PE|Peru|113 (press 5)|113|Press 5 after connecting
SR|Suriname|123
UY|Uruguay|0800 0767
VE|Venezuela|0424-290-7338
BH|Bahrain|3844 7588 (English)|38447588|Arabic line: 6671 0901
BD|Bangladesh|09638 881 888
BT|Bhutan|1010
BN|Brunei|145
KH|Cambodia|017 222 372
CN|China|12355
GE|Georgia|116 123
HK|Hong Kong|2389 2222
IN|India|14416
ID|Indonesia|119 (press 8)|119|Press 8 after connecting
IR|Iran|1480
IL|Israel|1201
IQ|Iraq|0750 309 6649||Second line: 053 339 0840
JP|Japan|0120 061 338
JO|Jordan|079 544 0416
KZ|Kazakhstan|150
KW|Kuwait|147
KG|Kyrgyzstan|111
LA|Laos|1362
LB|Lebanon|1564
MO|Macau|2852 5222
MY|Malaysia|15555
MV|Maldives|1677
MN|Mongolia|1800-2000
MM|Myanmar|09 765 400 200
NP|Nepal|1166
OM|Oman|800-77788
PK|Pakistan|0304 111 1741
PS|Palestine|164
PH|Philippines|1553
QA|Qatar|16000 (press 4)|16000|Press 4 after connecting
SA|Saudi Arabia|9200 33360
SG|Singapore|1767
KR|South Korea|109
LK|Sri Lanka|1926
SY|Syria|0944 868 444
TW|Taiwan|1925
TJ|Tajikistan|935 50 50 50
TH|Thailand|1323
TL|Timor-Leste|7725 4597
TR|Türkiye|183
TM|Turkmenistan|8 (12) 229 389
AE|United Arab Emirates|800 4673
UZ|Uzbekistan|71 276 49 66
VN|Vietnam|1900 6233
YE|Yemen|8000202
AX|Åland Islands|116 123
AL|Albania|0800 12345
AD|Andorra|177
AM|Armenia|0800 00 900
AT|Austria|142
BY|Belarus|8 (017) 311-00-99
BE|Belgium|107
BA|Bosnia and Herzegovina|080 05 03 05
BG|Bulgaria|0 8001 1466
HR|Croatia|0800 655 222
CY|Cyprus|8000 7773
CZ|Czech Republic|116 123
DK|Denmark|70 201 201
EE|Estonia|116 123
FO|Faroe Islands|0045 70 201 201
FI|Finland|09 2525 0111
FR|France|3114
DE|Germany|116 123
GI|Gibraltar|116 123
GR|Greece|1018
GG|Guernsey|116 123
HU|Hungary|116123
IS|Iceland|1717
IE|Ireland|116 123
IM|Isle of Man|0808 802 1221
IT|Italy|02 99777
JE|Jersey|116 123
XK|Kosovo|0800 12345
LV|Latvia|116123
LI|Liechtenstein|147
LT|Lithuania|116 123
LU|Luxembourg|45-45-45
MT|Malta|179
MD|Moldova|022 593 593
MC|Monaco|0800 91 90 10
ME|Montenegro|116 111
NL|Netherlands|113
MK|North Macedonia|070 390 632
NO|Norway|116 123
PL|Poland|116 123
PT|Portugal|1411
RO|Romania|0374 456 420
RU|Russia|8 (495) 989-50-50
SM|San Marino|800 995 988
RS|Serbia|0800/309-309
SK|Slovakia|0800 800 566
SI|Slovenia|116 123
ES|Spain|024
SJ|Svalbard|116 123
SE|Sweden|90101
CH|Switzerland|143
UA|Ukraine|0800100102
GB|United Kingdom|116 123
VA|Vatican City|06 7720 8977
AS|American Samoa|988
AU|Australia|13 11 14
FJ|Fiji|1543
GU|Guam|988
KI|Kiribati|189
MH|Marshall Islands|988
NR|Nauru|249
NC|New Caledonia|05 30 30
NZ|New Zealand|1737
NF|Norfolk Island|13 11 14
MP|Northern Mariana Islands|988
PW|Palau|988
PG|Papua New Guinea|7147 1518
WS|Samoa|800 7874
SB|Solomon Islands|699
TO|Tonga|22091
VU|Vanuatu|7716156 (Vodafone)||Digicel: 7716155
"""

    val all: List<Helpline> = RAW.trim().lines().mapNotNull { line ->
        val p = line.split("|")
        if (p.size < 3) return@mapNotNull null
        val dial = (p.getOrNull(3)?.takeIf { it.isNotBlank() } ?: p[2]).filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
        Helpline(p[0].trim(), p[1].trim(), p[2].trim(), dial, p.getOrNull(4)?.trim().orEmpty())
    }

    private val byIso = all.associateBy { it.iso }
    val sortedByCountry: List<Helpline> = all.sortedBy { it.country }

    fun forIso(iso: String?): Helpline? = iso?.uppercase(Locale.ROOT)?.let { byIso[it] }

    /** SIM country first, then network country, then the phone's region setting. */
    fun detectIso(ctx: Context): String? {
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val candidates = listOf(tm?.simCountryIso, tm?.networkCountryIso, Locale.getDefault().country)
        return candidates.firstOrNull { !it.isNullOrBlank() && byIso.containsKey(it.uppercase(Locale.ROOT)) }
            ?.uppercase(Locale.ROOT)
    }
}
