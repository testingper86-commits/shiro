package com.shiro.companion

import android.content.Context
import android.speech.SpeechRecognizer

class LoadFailure(val stage: String, cause: Throwable) : Exception(cause.message ?: cause.javaClass.simpleName, cause)

/** Process-wide holder for the loaded models, so they survive Activity re-creation. */
object Engine {
    @Volatile var brain: Brain? = null
        private set
    @Volatile var voiceIn: VoiceIn? = null
        private set
    @Volatile var voiceOut: VoiceOut? = null
        private set
    /** Loudness callback for the waveform (0..1). */
    @Volatile var onLevel: ((Float) -> Unit)? = null
        set(v) { field = v; mic.onLevel = v; (voiceIn as? SystemListener)?.onLevel = v }

    /** Why the brain could not start (null = fine). Shiro then still listens, detects crises and shows helplines. */
    @Volatile var brainFailure: Throwable? = null
        private set

    private val mic = MicListener()
    private var ears: Ears? = null
    private var mouth: Mouth? = null
    private var speaker: SystemSpeaker? = null
    private var earsCode: String? = null
    private var mouthVoice: String? = null
    private var brainPath: String? = null
    private val busy = java.util.concurrent.atomic.AtomicInteger(0)

    fun enter() { busy.incrementAndGet() }
    fun leave() { busy.decrementAndGet() }
    /** Frees the models only if nothing is using them right now. */
    fun releaseIfIdle() { if (busy.get() == 0) release() }

    /** Loads whatever is missing for [lang]. Blocking; call from a background thread. */
    @Synchronized
    fun prepare(ctx: Context, lang: Lang) {
        val app = ctx.applicationContext
        if (AppSettings.offlineVoice(app)) {
            closePhoneVoice()
            if (ears == null || earsCode != lang.code) {
                ears?.close(); ears = null
                ears = try { Ears(app, lang) } catch (t: Throwable) { throw LoadFailure("ears", t) }
                earsCode = lang.code
            }
            if (mouth == null || mouthVoice != lang.voice.id) {
                mouth?.close(); mouth = null
                mouth = try { Mouth(app, lang) } catch (t: Throwable) { throw LoadFailure("voice", t) }
                mouthVoice = lang.voice.id
            }
            voiceIn = OfflineIn(mic, ears!!)
            voiceOut = mouth
        } else {
            closeOfflineVoice()   // frees memory: only the brain stays loaded
            if (!SpeechRecognizer.isRecognitionAvailable(app)) {
                throw SpeechUnavailable(Tr.t("Your phone cannot recognise speech right now. Check the Google app or Speech Services, or switch to Offline voices in Settings."))
            }
            val sp = speaker ?: SystemSpeaker(app).also { speaker = it }
            sp.use(lang)
            voiceIn = SystemListener(app, lang)
            voiceOut = sp
        }
        val path = ModelStore.llmFile(app).absolutePath
        if (brain == null || brainPath != path) {
            brain?.close(); brain = null
            try { brain = Brain(app); brainPath = path; brainFailure = null }
            catch (t: Throwable) { brainFailure = t; brainPath = null }
        }
        onLevel = onLevel   // re-wire the waveform callback to the new listener
    }

    private fun closeOfflineVoice() {
        mouth?.close(); mouth = null; mouthVoice = null
        ears?.close(); ears = null; earsCode = null
    }

    private fun closePhoneVoice() {
        speaker?.close(); speaker = null
    }

    @Synchronized
    fun release() {
        closeOfflineVoice(); closePhoneVoice()
        voiceIn = null; voiceOut = null
        brain?.close(); brain = null; brainPath = null
    }
}
