package com.shiro.companion

import android.content.Context

class LoadFailure(val stage: String, cause: Throwable) : Exception(cause.message ?: cause.javaClass.simpleName, cause)

/** Process-wide holder for the loaded models, so they survive Activity re-creation. */
object Engine {
    @Volatile var brain: Brain? = null
        private set
    @Volatile var ears: Ears? = null
        private set
    @Volatile var mouth: Mouth? = null
        private set
    private var earsCode: String? = null
    private var mouthVoice: String? = null

    /** Loads whatever is missing for [lang]. Blocking; call from a background thread. */
    @Synchronized
    fun prepare(ctx: Context, lang: Lang) {
        val app = ctx.applicationContext
        if (ears == null || earsCode != lang.code) {
            ears?.close(); ears = null
            ears = try { Ears(app, lang) } catch (t: Throwable) { throw LoadFailure("ears", t) }
            earsCode = lang.code
        }
        if (mouth == null || mouthVoice != lang.voice.id) {
            mouth?.close(); mouth = null
            mouth = try { Mouth(app, lang) } catch (t: Throwable) { throw LoadFailure("voice", t) }
            mouthVoice = lang.voice.id
        }
        if (brain == null) brain = try { Brain(app) } catch (t: Throwable) { throw LoadFailure("brain", t) }
    }

    @Synchronized
    fun release() {
        mouth?.close(); mouth = null; mouthVoice = null
        ears?.close(); ears = null; earsCode = null
        brain?.close(); brain = null
    }

}
