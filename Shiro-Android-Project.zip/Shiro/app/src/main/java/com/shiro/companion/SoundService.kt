package com.shiro.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Keeps relaxing / sleep sounds playing when the screen turns off. Stops itself when the timer ends. */
class SoundService : Service() {
    private var gen: NoiseGenerator? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        val kinds = NoiseGenerator.Kind.values()
        val kind = kinds.getOrElse(intent?.getIntExtra(EXTRA_KIND, 0) ?: 0) { kinds[0] }
        val seconds = intent?.getIntExtra(EXTRA_SECONDS, 0) ?: 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(kind.label), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        gen?.stop()
        gen = NoiseGenerator(kind).also { it.start() }
        handler.removeCallbacksAndMessages(null)
        if (seconds > 0) handler.postDelayed({ shutdown() }, seconds * 1000L)
        running = true
        return START_NOT_STICKY
    }

    private fun buildNotification(label: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Relaxing sounds", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, SoundService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification).setContentTitle("Shiro").setContentText(label)
            .setContentIntent(open).addAction(0, "Stop", stop).setOngoing(true).build()
    }

    private fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        gen?.stop(); gen = null; running = false
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { gen?.stop(); running = false; super.onDestroy() }

    companion object {
        const val ACTION_STOP = "com.shiro.companion.STOP_SOUND"
        private const val EXTRA_KIND = "kind"
        private const val EXTRA_SECONDS = "seconds"
        private const val CHANNEL = "sounds"
        private const val NOTIFICATION_ID = 41
        @Volatile var running = false

        fun start(ctx: Context, kind: NoiseGenerator.Kind, seconds: Int) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, SoundService::class.java)
                .putExtra(EXTRA_KIND, kind.ordinal).putExtra(EXTRA_SECONDS, seconds))
        }

        fun stop(ctx: Context) {
            if (!running) return
            try { ctx.startService(Intent(ctx, SoundService::class.java).setAction(ACTION_STOP)) } catch (_: Exception) {}
        }
    }
}
