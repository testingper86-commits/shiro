package com.shiro.companion

/**
 * Decides whether the user explicitly asked Shiro to look something up online, and extracts the query.
 * Patterns are generated from gen/patterns.py (tested there). Only explicit requests ("search for...",
 * "look up...") or live-information questions (weather, news, prices...) trigger a search, and
 * live-information words are ignored when the sentence sounds like the user talking about their feelings.
 */
object SearchIntent {
    private class IntentSet(verb: String, live: String, lead: String, tail: String, block: String) {
        val verb = Regex(verb, RegexOption.IGNORE_CASE)
        val live = Regex(live, RegexOption.IGNORE_CASE)
        val lead = Regex(lead, RegexOption.IGNORE_CASE)
        val tail = Regex(tail, RegexOption.IGNORE_CASE)
        val block = Regex(block, RegexOption.IGNORE_CASE)
    }

    private val sets: Map<String, IntentSet> = mapOf(
        "en" to IntentSet(
            verb = """^\W*(?:(?:please|hey|hi|ok|okay|shiro|can you|could you|would you|will you|go and|go|just|now)\s+)*(?:search(?: the (?:web|internet|net))?(?: for| about| up)?|look(?: it| that| this)? up(?! to\b)|lookup|google|find out|find me|check online|browse(?: the web)?)\b\s*""",
            live = """\b(?:weather|forecast|news|headlines|price of|stock price|exchange rate|score of|who won|release date|latest (?:news|update|updates|version|on|about))\b""",
            lead = """^(?:(?:for|about|up|on|the|internet|web|information|info|please|me)\b\s*)+""",
            tail = """(?:\s+(?:on the (?:internet|web)|online|please))+\s*$""",
            block = """\b(?:i am|i['’]m|i feel|i felt|i can['’]t|i cannot|i don['’]t|i hate|i keep|my life|stressed|anxious|worried|scared|sad|depressed|lonely|tired of|overwhelmed)\b"""
        ),
        "hi" to IntentSet(
            verb = """(?:सर्च\s*कर\S*|खोज\s*कर\S*|खोजो|ढूं?ढ\s*कर\S*|ढूँढ\s*कर\S*|ढूंढो|ढूँढो|गूगल\s*कर\S*|इंटरनेट\s*पर\s*(?:देख|खोज|सर्च)\S*|ऑनलाइन\s*(?:देख|खोज|सर्च)\S*)""",
            live = """मौसम|खबर|ख़बर|समाचार|न्यूज""",
            lead = """^(?:(?:कृपया|मुझे|के बारे में|बारे में|इंटरनेट पर|ऑनलाइन)\s*)+""",
            tail = """(?:\s+(?:कृपया|प्लीज़|प्लीज))+\s*$""",
            block = """मैं\s|मुझे\s|मेरा\s|मेरी\s|तनाव|चिंता|उदास|अकेला|अकेली|डर"""
        ),
        "es" to IntentSet(
            verb = """^\W*(?:(?:por favor|oye|hola|shiro|puedes|podrías|podrias)\s+)*(?:busca(?:r|me)?|búscame|investiga|googlea|averigua)\b\s*""",
            live = """clima|pronóstico|pronostico|noticias|precio de|quién ganó|quien gano|resultado del""",
            lead = """^(?:(?:sobre|acerca de|en internet|por internet|me)\s+)+""",
            tail = """(?:\s+(?:en internet|por internet|por favor))+\s*$""",
            block = """estoy|me siento|no puedo|tengo (?:miedo|estrés|estres|ansiedad)|estresad|ansios|triste|solo\b|sola\b|mi vida"""
        ),
        "fr" to IntentSet(
            verb = """^\W*(?:(?:s['’]il te pla[iî]t|s['’]il vous pla[iî]t|stp|salut|shiro|peux-tu|pourrais-tu|peux tu|pourrais tu)\s+)*(?:cherche|recherche|renseigne-toi|google)\b\s*""",
            live = """météo|actualité|dernières nouvelles|prix de|qui a gagné""",
            lead = """^(?:(?:sur internet|sur|à propos de|moi)\s+)+""",
            tail = """(?:\s+(?:sur internet|s['’]il te pla[iî]t|stp))+\s*$""",
            block = """je suis|je me sens|je n['’]arrive|j['’]ai (?:peur|honte)|stress|anxieu|triste|seul|ma vie"""
        ),
        "it" to IntentSet(
            verb = """^\W*(?:(?:per favore|ciao|shiro|puoi|potresti)\s+)*(?:cerca|cercami|ricerca|googla|informati)\b\s*""",
            live = """meteo|notizie|prezzo di|chi ha vinto""",
            lead = """^(?:(?:su internet|riguardo a|per me|su)\s+)+""",
            tail = """(?:\s+(?:su internet|per favore))+\s*$""",
            block = """sono\s|mi sento|non riesco|ho paura|stress|ansios|triste|solo\b|sola\b|la mia vita"""
        ),
        "pt" to IntentSet(
            verb = """^\W*(?:(?:por favor|oi|olá|shiro|você pode|voce pode|pode|poderia)\s+)*(?:pesquise|pesquisa|procure|busque|googla|descubra)\b\s*""",
            live = """previsão do tempo|previsao do tempo|clima|notícias|noticias|preço d|quem ganhou""",
            lead = """^(?:(?:sobre|na internet|pela internet|por mim|para mim)\s+)+""",
            tail = """(?:\s+(?:na internet|pela internet|por favor))+\s*$""",
            block = """estou|me sinto|não consigo|nao consigo|tenho (?:medo|estresse|ansiedade)|estress|ansios|triste|sozinh|minha vida"""
        ),
    )

    /** Returns the search query, or null if this is not a search request. */
    fun extract(utterance: String, langCode: String): String? {
        val s = sets[langCode] ?: sets.getValue("en")
        val t = Safety.normalize(utterance.trim())
        if (t.isEmpty()) return null
        var q: String = when {
            s.verb.containsMatchIn(t) -> s.verb.replaceFirst(t, " ")
            s.live.containsMatchIn(t) && !s.block.containsMatchIn(t) -> t
            else -> return null
        }
        q = q.trim().trimEnd('?', '.', '!', '।').trim()
        repeat(3) {
            q = s.lead.replaceFirst(q, "").trim()
            q = s.tail.replaceFirst(q, "").trim()
        }
        return if (q.length >= 2) q else t
    }
}
