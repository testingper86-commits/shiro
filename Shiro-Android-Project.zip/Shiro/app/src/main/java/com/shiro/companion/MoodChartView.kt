package com.shiro.companion

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Line chart of the last days' mood scores (1 = Sad ... 5 = Great); null = no entry. */
class MoodChartView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var scores: List<Int?> = emptyList()
        set(v) { field = v; invalidate() }
    var labels: List<String> = emptyList()
        set(v) { field = v; invalidate() }

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f; color = 0xFF6C9BFF.toInt(); style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFA9B7F0.toInt(); textAlign = Paint.Align.CENTER }
    private val colors = intArrayOf(0, 0xFFA77BFF.toInt(), 0xFFFF5C5C.toInt(), 0xFFFF9F43.toInt(), 0xFFF4C430.toInt(), 0xFF3DDC84.toInt())

    override fun onDraw(c: Canvas) {
        val n = scores.size
        if (n == 0) return
        text.textSize = 11f * resources.displayMetrics.scaledDensity
        val w = width.toFloat(); val labelH = text.textSize * 1.6f
        val top = 16f; val bottom = height - labelH - 8f
        val slot = w / n
        fun x(i: Int) = slot * i + slot / 2
        fun y(s: Int) = bottom - (s - 1) / 4f * (bottom - top)
        var prev: Int? = null
        for (i in 0 until n) {
            val s = scores[i]
            if (s != null && prev != null) c.drawLine(x(prev), y(scores[prev]!!), x(i), y(s), line)
            if (s != null) prev = i
        }
        for (i in 0 until n) {
            scores[i]?.let { dot.color = colors[it]; c.drawCircle(x(i), y(it), 9f, dot) }
            labels.getOrNull(i)?.let { c.drawText(it, x(i), height - 8f, text) }
        }
    }
}
