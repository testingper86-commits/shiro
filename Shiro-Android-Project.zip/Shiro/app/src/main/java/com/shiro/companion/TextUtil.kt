package com.shiro.companion

object TextUtil {
    private val url = Regex("""https?://\S+""")
    private val markup = Regex("""[*_#`>~|\[\]{}]""")
    private val emoji = Regex("""[\p{So}\uD83C-\uDBFF\uDC00-\uDFFF\u200D\uFE0F]""")
    private val spaces = Regex("""\s+""")
    private val sentenceEnd = Regex("""(?<=[.!?।۔؟])\s+""")

    /** Removes things a voice should not read out: links, markdown symbols, emoji. */
    fun cleanForSpeech(text: String): String =
        text.replace(url, " ").replace(markup, " ").replace(emoji, " ").replace(spaces, " ").trim()

    /** Splits into speakable chunks (<= maxLen characters) so the first words are heard sooner. */
    fun splitSentences(text: String, maxLen: Int = 240): List<String> {
        val out = ArrayList<String>()
        for (s in text.split(sentenceEnd).map { it.trim() }.filter { it.isNotEmpty() }) {
            var rest = s
            while (rest.length > maxLen) {
                var cut = rest.lastIndexOf(',', maxLen)
                if (cut < maxLen / 3) cut = rest.lastIndexOf(' ', maxLen)
                if (cut <= 0) cut = maxLen
                out.add(rest.substring(0, cut + 1).trim())
                rest = rest.substring(cut + 1).trim()
            }
            if (rest.isNotEmpty()) out.add(rest)
        }
        return out
    }

    /** Keeps replies short: at most [max] sentences (the small model can ramble). */
    fun limitSentences(text: String, max: Int): String {
        val parts = text.split(sentenceEnd).filter { it.isNotBlank() }
        return if (parts.size <= max) text.trim() else parts.take(max).joinToString(" ").trim()
    }

    private val noise = setOf(
        "you", "thank you", "thanks", "thanks for watching", "thank you for watching", "bye", "okay", "ok",
        "subtitles by the amara.org community", "hmm", "um", "uh", "mm", "please subscribe", "bye bye", "see you next time"
    )

    /** Whisper tends to invent short phrases from silence or noise. */
    fun isLikelyNoise(heard: String): Boolean {
        val t = heard.lowercase().replace(Regex("""[\p{Punct}\s]+"""), " ").trim()
        return t.length < 2 || t in noise
    }
}
