package com.shiro.companion

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.IOException
import java.util.Calendar
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {

    private enum class Screen { SPLASH, HOME, CONV, WELLNESS, MOOD, GROWTH, SETTINGS, EXERCISE }
    private enum class State { IDLE, LOADING, LISTENING, THINKING, SEARCHING, SPEAKING }
    private class Step(val text: String, val seconds: Int, val scale: Float)

    // views
    private lateinit var splash: View
    private lateinit var home: View
    private lateinit var conversation: View
    private lateinit var wellnessV: View
    private lateinit var moodV: View
    private lateinit var growthV: View
    private lateinit var settingsV: View
    private lateinit var exerciseV: View
    private lateinit var nav: LinearLayout
    private lateinit var setupPanel: View
    private lateinit var setupText: TextView
    private lateinit var downloadBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var tapLabel: TextView
    private lateinit var tapSub: TextView
    private lateinit var greeting: TextView
    private lateinit var convStatus: TextView
    private lateinit var convTitle: TextView
    private lateinit var convLogo: ImageView
    private lateinit var wave: WaveformView
    private lateinit var orbGroup: View
    private lateinit var transcriptScroll: ScrollView
    private lateinit var transcript: LinearLayout
    private lateinit var muteBtn: TextView
    private lateinit var muteLabel: TextView
    private lateinit var exTitle: TextView
    private lateinit var exText: TextView
    private lateinit var exTimer: TextView
    private lateinit var exCircle: ImageView

    private lateinit var prefs: SharedPreferences
    private lateinit var stores: Stores
    private lateinit var lang: Lang
    private var screen = Screen.HOME
    private var pulse: ObjectAnimator? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var soundExercise = false
    private var exTick: Runnable? = null

    @Volatile private var running = false
    @Volatile private var muted = false
    @Volatile private var downloading = false
    @Volatile private var destroyed = false
    @Volatile private var recording = false
    @Volatile private var errorText: String? = null
    @Volatile private var failedStage: String? = null
    private var loop: Thread? = null
    private val mic = MicListener()
    private var focusRequest: AudioFocusRequest? = null
    private var afterMic: (() -> Unit)? = null

    // ================= setup =================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        splash = findViewById(R.id.splash); home = findViewById(R.id.home); conversation = findViewById(R.id.conversation)
        wellnessV = findViewById(R.id.wellness); moodV = findViewById(R.id.mood); growthV = findViewById(R.id.growth)
        settingsV = findViewById(R.id.settings); exerciseV = findViewById(R.id.exercise)
        nav = findViewById(R.id.nav); setupPanel = findViewById(R.id.setupPanel); setupText = findViewById(R.id.setupText)
        downloadBtn = findViewById(R.id.downloadBtn); progress = findViewById(R.id.progress); progressText = findViewById(R.id.progressText)
        tapLabel = findViewById(R.id.tapLabel); tapSub = findViewById(R.id.tapSub); greeting = findViewById(R.id.greeting)
        convStatus = findViewById(R.id.convStatus); convTitle = findViewById(R.id.convTitle); convLogo = findViewById(R.id.convLogo)
        wave = findViewById(R.id.wave); orbGroup = findViewById(R.id.orbGroup)
        transcriptScroll = findViewById(R.id.transcriptScroll); transcript = findViewById(R.id.transcript)
        muteBtn = findViewById(R.id.muteBtn); muteLabel = findViewById(R.id.muteLabel)
        exTitle = findViewById(R.id.exTitle); exText = findViewById(R.id.exText); exTimer = findViewById(R.id.exTimer); exCircle = findViewById(R.id.exCircle)

        prefs = getSharedPreferences("shiro", MODE_PRIVATE)
        stores = Stores(this)
        lang = Languages.byCode(prefs.getString("lang", "en"))
        Tr.hindi = lang.code == "hi"

        for (id in intArrayOf(R.id.splashLogo, R.id.homeAvatar, R.id.orbLogo, R.id.convLogo, R.id.exCircle)) {
            findViewById<ImageView>(id).apply { outlineProvider = android.view.ViewOutlineProvider.BACKGROUND; clipToOutline = true }
        }
        findViewById<View>(R.id.getStarted).setOnClickListener { prefs.edit().putBoolean("onboarded", true).apply(); show(Screen.HOME) }
        findViewById<View>(R.id.homeHelp).setOnClickListener { showHelplines() }
        findViewById<View>(R.id.convHelp).setOnClickListener { showHelplines() }
        findViewById<View>(R.id.homeGear).setOnClickListener { show(Screen.SETTINGS) }
        findViewById<View>(R.id.orbLogo).setOnClickListener { onTalk() }
        findViewById<View>(R.id.micBtn).setOnClickListener { onTalk() }
        findViewById<View>(R.id.convBack).setOnClickListener { endConversation() }
        findViewById<View>(R.id.endBtn).setOnClickListener { endConversation() }
        findViewById<View>(R.id.stopBtn).setOnClickListener { Engine.mouth?.stop() }
        muteBtn.setOnClickListener {
            muted = !muted
            muteLabel.text = if (muted) tr("Unmute") else tr("Mute")
            muteBtn.alpha = if (muted) 0.5f else 1f
        }
        findViewById<View>(R.id.exStop).setOnClickListener { stopExercise(); show(Screen.WELLNESS) }
        downloadBtn.setOnClickListener { startDownload() }

        buildTiles(); buildNav(); applyTexts()
        mic.onLevel = { wave.setLevel(it) }
        show(if (prefs.getBoolean("onboarded", false)) Screen.HOME else Screen.SPLASH)
        refreshSetup()
    }

    private fun tr(s: String) = Tr.t(s)

    private fun applyTexts() {
        findViewById<TextView>(R.id.splashLine).text = tr("Your Safe Space\nTo Feel, Heal & Grow")
        findViewById<TextView>(R.id.splashSub).text = tr("You're not alone. I'm here.")
        findViewById<TextView>(R.id.tag1).text = "🪷\n" + tr("Less Stress")
        findViewById<TextView>(R.id.tag2).text = "♡\n" + tr("More Peace")
        findViewById<TextView>(R.id.tag3).text = "🌱\n" + tr("Better You")
        findViewById<TextView>(R.id.tag4).text = "👥\n" + tr("Humanity")
        findViewById<TextView>(R.id.getStarted).text = tr("Get Started  →")
        findViewById<TextView>(R.id.homeHelp).text = tr("♡ Need help?")
        findViewById<TextView>(R.id.convHelp).text = tr("♡ Need help?")
        findViewById<TextView>(R.id.homeSub).text = tr("Take a deep breath…\nYou're doing better than you think.")
        tapSub.text = tr("Shiro is here for you")
        findViewById<TextView>(R.id.convHint).text = tr("Take your time. I'm here.")
        findViewById<TextView>(R.id.endLabel).text = tr("End")
        findViewById<TextView>(R.id.stopLabel).text = tr("Stop")
        findViewById<TextView>(R.id.exStop).text = tr("Stop")
        muteLabel.text = tr(if (muted) "Unmute" else "Mute")
    }

    private fun rebuildStatic() {
        findViewById<LinearLayout>(R.id.tiles).removeAllViews(); buildTiles()
        for (i in 0 until nav.childCount) (nav.getChildAt(i) as TextView).text = "${navItems[i].first}\n${tr(navItems[i].second)}"
        greeting.text = greetingText()
    }

    private fun buildTiles() {
        val tiles = findViewById<LinearLayout>(R.id.tiles)
        tiles.addView(UiKit.tile(this, "🍃", tr("Calm"), tr("(For Stress)")) { startQuickRelief() })
        tiles.addView(UiKit.tile(this, "🌙", tr("Sleep"), tr("(For Rest)")) { startSleep() })
        tiles.addView(UiKit.tile(this, "🙂", tr("Mood"), tr("(Track)")) { show(Screen.MOOD) })
        tiles.addView(UiKit.tile(this, "🌱", tr("Growth"), tr("(Your Goals)")) { show(Screen.GROWTH) })
    }

    private val navItems = listOf(
        Triple("⌂", "Home", Screen.HOME), Triple("♡", "Wellness", Screen.WELLNESS),
        Triple("🌱", "Growth", Screen.GROWTH), Triple("⚙", "Settings", Screen.SETTINGS)
    )

    private fun buildNav() {
        for ((icon, label, target) in navItems) {
            nav.addView(TextView(this).apply {
                text = "$icon\n${tr(label)}"; gravity = Gravity.CENTER; textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                setOnClickListener { if (!running) show(target) }
            })
        }
    }

    private fun show(s: Screen) {
        if (s != Screen.EXERCISE && screen == Screen.EXERCISE) stopExercise()
        screen = s
        val views = mapOf(
            Screen.SPLASH to splash, Screen.HOME to home, Screen.CONV to conversation, Screen.WELLNESS to wellnessV,
            Screen.MOOD to moodV, Screen.GROWTH to growthV, Screen.SETTINGS to settingsV, Screen.EXERCISE to exerciseV
        )
        for ((k, v) in views) v.visibility = if (k == s) View.VISIBLE else View.GONE
        nav.visibility = if (s in listOf(Screen.HOME, Screen.WELLNESS, Screen.MOOD, Screen.GROWTH, Screen.SETTINGS)) View.VISIBLE else View.GONE
        val highlighted = if (s == Screen.MOOD) Screen.GROWTH else s
        for (i in 0 until nav.childCount) {
            (nav.getChildAt(i) as TextView).setTextColor(
                if (navItems[i].third == highlighted) ContextCompat.getColor(this, R.color.shiro_nav_on) else ContextCompat.getColor(this, R.color.shiro_soft)
            )
        }
        when (s) {
            Screen.HOME -> { greeting.text = greetingText(); refreshSetup() }
            Screen.WELLNESS -> buildWellness()
            Screen.MOOD -> buildMood()
            Screen.GROWTH -> buildGrowth()
            Screen.SETTINGS -> buildSettings()
            else -> {}
        }
    }

    private fun greetingText(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (h < 12) tr("Good morning") else if (h < 18) tr("Good afternoon") else tr("Good evening")
    }

    private fun refreshSetup() {
        if (ModelStore.ready(this, lang)) {
            setupPanel.visibility = View.GONE
            if (!running) setStatus(lang.tap)
        } else {
            setupPanel.visibility = if (screen == Screen.HOME) View.VISIBLE else View.GONE
            val mb = ModelStore.missingMb(this, lang)
            setupText.text = Tr.f("Shiro needs a one-time download (about %d MB) to talk with you in %s. After that it works offline, except when you ask Shiro to search the internet.", mb, lang.label)
            downloadBtn.text = Tr.f("Download (about %d MB)", mb)
            tapLabel.text = lang.tap
        }
    }

    private fun setStatus(t: String) = runOnUiThread {
        tapLabel.text = t; convStatus.text = t; convTitle.text = t
    }

    // ================= download =================

    private fun startDownload() {
        if (downloading) return
        val mem = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mem)
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val warnings = ArrayList<String>()
        if (cm.isActiveNetworkMetered) warnings.add(tr("You seem to be on mobile data. This download is large; Wi-Fi is recommended."))
        if (mem.totalMem < 5_000_000_000L) warnings.add(tr("This phone has little memory. Shiro may be slow or may stop on this phone."))
        if (warnings.isEmpty()) { runDownload(); return }
        AlertDialog.Builder(this).setTitle(tr("Before you download")).setMessage(warnings.joinToString("\n\n"))
            .setPositiveButton(tr("Download anyway")) { _, _ -> runDownload() }.setNegativeButton(tr("Not now"), null).show()
    }

    private fun runDownload() {
        downloading = true
        downloadBtn.isEnabled = false
        progress.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val l = lang
        Thread {
            var failure: String? = null
            try {
                val report = { label: String, pct: Int -> runOnUiThread { progress.progress = pct; progressText.text = "${tr(label)}  $pct%" } }
                if (!ModelStore.coreReady(this)) ModelStore.downloadCore(this, { destroyed }, report)
                if (!ModelStore.voiceReady(this, l.voice)) ModelStore.downloadVoice(this, l.voice, { destroyed }, report)
            } catch (e: DownloadCancelled) {
                failure = ""
            } catch (e: Exception) {
                failure = (e.message ?: tr("The download stopped.")) + " " + tr("Tap the button to try again.")
            } finally {
                downloading = false
                if (!destroyed) runOnUiThread {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    downloadBtn.isEnabled = true
                    progress.visibility = View.GONE
                    progressText.text = ""
                    refreshSetup()
                    if (!failure.isNullOrEmpty()) progressText.text = failure
                }
            }
        }.start()
    }

    // ================= talking =================

    private fun withMic(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) action()
        else { afterMic = action; ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1) }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != 1) return
        val a = afterMic; afterMic = null
        if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) a?.invoke()
        else Toast.makeText(this, tr("Shiro needs the microphone permission to hear you. You can allow it in the phone's app settings."), Toast.LENGTH_LONG).show()
    }

    private fun onTalk() {
        if (downloading || !ModelStore.ready(this, lang) || running || recording) return
        withMic { startConversation() }
    }

    private fun askNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
    }

    private fun speechSpeed(): Float = when (prefs.getInt("speed", 1)) { 0 -> 0.85f; 2 -> 1.15f; else -> 1.0f }
    private fun captionsOn() = prefs.getBoolean("captions", false)

    private fun addBubble(text: String, fromUser: Boolean) {
        if (!captionsOn()) return
        runOnUiThread {
            transcript.addView(UiKit.bubble(this, text, fromUser))
            transcriptScroll.post { transcriptScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun startConversation() {
        if (running) return
        running = true; muted = false; muteLabel.text = tr("Mute"); muteBtn.alpha = 1f
        errorText = null; failedStage = null
        stores.addSession()
        transcript.removeAllViews()
        orbGroup.visibility = if (captionsOn()) View.GONE else View.VISIBLE
        transcriptScroll.visibility = if (captionsOn()) View.VISIBLE else View.GONE
        show(Screen.CONV)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestAudioFocus()
        val l = lang
        loop = Thread {
            try {
                setState(State.LOADING)
                Engine.prepare(this, l)
                val b = Engine.brain!!; val e = Engine.ears!!; val m = Engine.mouth!!
                setState(State.SPEAKING)
                addBubble(l.greeting, false)
                m.speak(l.greeting, speechSpeed()) { !running }
                var quiet = 0
                while (running) {
                    while (running && muted) { setStatus("🎙 ✕"); Thread.sleep(250) }
                    if (!running) break
                    setState(State.LISTENING)
                    val audio = mic.capture { !running || muted }
                    if (!running) break
                    if (muted) continue
                    if (audio == null) { if (++quiet >= 3) break else continue }
                    quiet = 0
                    setState(State.THINKING)
                    val heard = e.transcribe(audio)
                    if (TextUtil.isLikelyNoise(heard)) continue
                    addBubble(heard, true)
                    var answer: String
                    if (Safety.isCrisis(heard, l)) {
                        answer = l.crisisReply
                        b.remember(heard, answer)
                        runOnUiThread { showHelplines() }
                    } else {
                        val query = SearchIntent.extract(heard, l.code)
                        answer = if (query != null) answerWithSearch(heard, query, l, b) else b.reply(heard, l)
                        if (Safety.isUnsafeReply(answer)) { answer = l.crisisReply; runOnUiThread { showHelplines() } }
                    }
                    if (!running) break
                    setState(State.SPEAKING)
                    addBubble(answer, false)
                    m.speak(answer, speechSpeed()) { !running }
                    if (running) Thread.sleep(350)
                }
            } catch (t: LoadFailure) {
                failedStage = t.stage
                errorText = if (t.cause is OutOfMemoryError) tr("Not enough memory to start Shiro on this phone.")
                else Tr.f("Shiro could not start (%s: %s).", t.stage, t.message ?: "")
            } catch (t: Throwable) {
                errorText = Tr.f("Something went wrong: %s", t.message ?: t.javaClass.simpleName)
            } finally {
                running = false
                abandonAudioFocus()
                val err = errorText; val stage = failedStage
                if (!destroyed) runOnUiThread {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    stopPulse(); wave.synthetic = false; wave.setLevel(0f)
                    if (screen == Screen.CONV) show(Screen.HOME)
                    tapLabel.text = err ?: l.tap
                    if (err != null && stage != null) showRepair(err, stage)
                }
            }
        }.also { it.start() }
    }

    private fun endConversation() {
        running = false
        Engine.mouth?.stop()
        if (screen == Screen.CONV) show(Screen.HOME)
    }

    private fun setState(s: State) = runOnUiThread {
        val t = when (s) {
            State.IDLE -> lang.tap; State.LOADING -> lang.loading; State.LISTENING -> lang.listening
            State.THINKING -> lang.thinking; State.SEARCHING -> lang.searching; State.SPEAKING -> lang.speaking
        }
        tapLabel.text = t; convStatus.text = t; convTitle.text = t
        wave.synthetic = (s == State.SPEAKING)
        if (s != State.LISTENING) wave.setLevel(0f)
        when (s) {
            State.LISTENING -> startPulse(1.05f, 1400)
            State.SPEAKING -> startPulse(1.09f, 500)
            State.LOADING, State.THINKING, State.SEARCHING -> startPulse(1.03f, 900)
            State.IDLE -> stopPulse()
        }
    }

    private fun startPulse(scale: Float, ms: Long) {
        pulse?.cancel()
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            convLogo, PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, scale), PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, scale)
        ).apply { duration = ms; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator(); start() }
    }

    private fun stopPulse() { pulse?.cancel(); convLogo.scaleX = 1f; convLogo.scaleY = 1f }

    // ================= internet search =================

    private fun searchOn() = prefs.getString("search", "unset") == "on"

    private fun showSearchConsent(onResult: (Boolean) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(tr("Let Shiro look things up online?"))
            .setMessage(tr("When you ask Shiro to search (for example \"search for…\", the weather or the news), only the words of that question are sent to DuckDuckGo and Wikipedia. Nothing else leaves your phone, and conversations about your feelings are never sent. You can turn this off at any time in Settings."))
            .setCancelable(false)
            .setPositiveButton(tr("Allow")) { _, _ -> onResult(true) }
            .setNegativeButton(tr("Not now")) { _, _ -> onResult(false) }
            .show()
    }

    private fun askSearchConsent(): Boolean {
        val latch = CountDownLatch(1); val allowed = AtomicBoolean(false)
        runOnUiThread { if (destroyed) latch.countDown() else showSearchConsent { ok -> allowed.set(ok); latch.countDown() } }
        latch.await(180, TimeUnit.SECONDS)
        return allowed.get()
    }

    private fun answerWithSearch(heard: String, query: String, l: Lang, b: Brain): String {
        when (prefs.getString("search", "unset")) {
            "off" -> return l.searchOff
            "on" -> {}
            else -> {
                if (askSearchConsent()) prefs.edit().putString("search", "on").apply()
                else { prefs.edit().putString("search", "off").apply(); return l.searchOff }
            }
        }
        if (!WebSearch.isOnline(this)) return l.noInternet
        setState(State.SEARCHING)
        val results = try { WebSearch.search(query, l.code) } catch (e: IOException) { return l.noInternet }
        if (results.isEmpty()) return l.searchFailed
        setState(State.THINKING)
        return b.reply(heard, l, WebSearch.formatForPrompt(results))
    }

    // ================= wellness exercises =================

    private fun startExercise(title: String, steps: List<Step>, repeat: Boolean, kind: NoiseGenerator.Kind?, total: Int?, idle: String = "") {
        if (running || recording) { Toast.makeText(this, tr("Please end the conversation first."), Toast.LENGTH_SHORT).show(); return }
        stopExercise()
        exTitle.text = title; exText.text = idle; exTimer.text = ""
        show(Screen.EXERCISE)
        soundExercise = kind != null
        if (kind != null) { askNotificationPermission(); SoundService.start(this, kind, total ?: 0) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val endAt = total?.let { SystemClock.elapsedRealtime() + it * 1000L }
        var idx = 0; var remain = 0
        val tick = object : Runnable {
            override fun run() {
                if (screen != Screen.EXERCISE) return
                val now = SystemClock.elapsedRealtime()
                if (endAt != null && now >= endAt) { finishExercise(); return }
                if (remain <= 0 && steps.isNotEmpty()) {
                    if (idx >= steps.size) { if (repeat) idx = 0 else { finishExercise(); return } }
                    val st = steps[idx++]
                    exText.text = st.text; remain = st.seconds
                    exCircle.animate().scaleX(st.scale).scaleY(st.scale).setDuration(st.seconds * 1000L).start()
                }
                remain--
                if (endAt != null) { val s = ((endAt - now) / 1000).toInt(); exTimer.text = "%d:%02d".format(s / 60, s % 60) }
                handler.postDelayed(this, 1000)
            }
        }
        exTick = tick
        handler.post(tick)
    }

    private fun finishExercise() {
        stopExercise()
        Toast.makeText(this, tr("Well done 💙"), Toast.LENGTH_LONG).show()
        show(Screen.WELLNESS)
    }

    private fun stopExercise() {
        exTick?.let { handler.removeCallbacks(it) }; exTick = null
        if (soundExercise) { SoundService.stop(this); soundExercise = false }
        exCircle.animate().cancel(); exCircle.scaleX = 1f; exCircle.scaleY = 1f
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun startBreathing() = startExercise(tr("Guided Breathing"),
        listOf(Step(tr("Breathe in…"), 4, 1.25f), Step(tr("Hold…"), 4, 1.25f), Step(tr("Breathe out slowly…"), 6, 0.8f)), true, null, 300)

    private fun startMeditation() = startExercise(tr("Meditation"),
        listOf(
            tr("Sit or lie down comfortably. Let your shoulders drop."), tr("Close your eyes if you like. Notice your breath, just as it is."),
            tr("Breathe in slowly… and breathe out slowly."), tr("If thoughts come, let them pass like clouds."),
            tr("Feel your feet, your legs, your back. Let them be heavy."), tr("Breathe in calm… breathe out tension."),
            tr("Remember: you don't have to fix anything right now."), tr("Take one more slow breath. When you're ready, open your eyes.")
        ).mapIndexed { i, t -> Step(t, 20, if (i % 2 == 0) 1.15f else 0.9f) }, false, null, null)

    private fun startQuickRelief() = startExercise(tr("Quick Relief"),
        listOf(
            Step(tr("Take one slow breath in… and out."), 12, 1.2f), Step(tr("Look around. Name 5 things you can see."), 15, 1.0f),
            Step(tr("Notice 4 things you can touch."), 15, 1.05f), Step(tr("Listen. Name 3 things you can hear."), 15, 1.0f),
            Step(tr("Notice 2 things you can smell."), 15, 1.05f), Step(tr("Name 1 thing you like about yourself."), 15, 1.0f),
            Step(tr("Breathe in slowly… and out. You are safe in this moment."), 12, 1.2f)
        ), false, null, null)

    private fun pickSound(onPick: (NoiseGenerator.Kind) -> Unit) {
        val kinds = NoiseGenerator.Kind.values()
        AlertDialog.Builder(this).setTitle(tr("Choose a sound"))
            .setItems(kinds.map { tr(it.label) }.toTypedArray()) { _, i -> onPick(kinds[i]) }.show()
    }

    private fun startSounds() = pickSound { k ->
        startExercise(Tr.f("Relaxing Sounds · %s", tr(k.label)), emptyList(), false, k, null, tr("Relax and listen…"))
    }

    private fun startSleep() {
        val mins = intArrayOf(15, 30, 60)
        AlertDialog.Builder(this).setTitle(tr("Sleep timer"))
            .setItems(arrayOf(tr("15 minutes"), tr("30 minutes"), tr("60 minutes"))) { _, i ->
                pickSound { k ->
                    Toast.makeText(this, tr("The sounds keep playing when the screen turns off. Tap Stop in the notification to end them."), Toast.LENGTH_LONG).show()
                    startExercise(tr("Sleep Support"), listOf(Step(tr("Breathe in slowly… let your body get heavy."), 8, 1.15f), Step(tr("Breathe out slowly… let go."), 10, 0.85f)),
                        true, k, mins[i] * 60)
                }
            }.show()
    }

    // ================= list screens =================

    private fun buildWellness() {
        val box = findViewById<LinearLayout>(R.id.wellnessBox); box.removeAllViews()
        box.addView(UiKit.title(this, tr("Wellness"), tr("Relax • Breathe • Feel Better")) { show(Screen.HOME) })
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_card); setPadding(UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 36), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 36))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = UiKit.dp(this@MainActivity, 12) }
            setOnClickListener { startBreathing() }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(TextView(this).apply { text = tr("Guided Breathing"); textSize = 20f; setTextColor(0xFFFFFFFF.toInt()) })
        col.addView(TextView(this).apply { text = tr("Calm your mind in minutes"); textSize = 13f; setTextColor(0xFFA9B7F0.toInt()) })
        hero.addView(col)
        hero.addView(TextView(this).apply { text = "▶"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()); setBackgroundResource(R.drawable.bg_circle_outline)
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 48), UiKit.dp(this@MainActivity, 48)) })
        box.addView(hero)
        box.addView(UiKit.row(this, "🪷", tr("Meditation"), tr("Find inner peace")) { startMeditation() })
        box.addView(UiKit.row(this, "🎵", tr("Relaxing Sounds"), tr("Rain • Ocean • Wind")) { startSounds() })
        box.addView(UiKit.row(this, "🌙", tr("Sleep Support"), tr("Better sleep, better you")) { startSleep() })
        box.addView(UiKit.row(this, "⚡", tr("Quick Relief"), tr("For overwhelming moments")) { startQuickRelief() })
    }

    private fun buildMood() {
        val box = findViewById<LinearLayout>(R.id.moodBox); box.removeAllViews()
        box.addView(UiKit.title(this, tr("Mood Tracker"), tr("How are you feeling today?")) { show(Screen.GROWTH) })
        val faces = listOf("😄" to tr("Great"), "🙂" to tr("Good"), "😐" to tr("Okay"), "😟" to tr("Low"), "😢" to tr("Sad"))
        val today = stores.moodToday()
        val rowV = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; weightSum = 5f; setBackgroundResource(R.drawable.bg_card)
            setPadding(UiKit.dp(this@MainActivity, 6), UiKit.dp(this@MainActivity, 10), UiKit.dp(this@MainActivity, 6), UiKit.dp(this@MainActivity, 10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = UiKit.dp(this@MainActivity, 12) }
        }
        faces.forEachIndexed { i, (face, label) ->
            val score = 5 - i
            rowV.addView(TextView(this).apply {
                text = "$face\n$label"; gravity = Gravity.CENTER; textSize = 13f
                setTextColor(if (today == score) 0xFFFFFFFF.toInt() else 0xFFA9B7F0.toInt())
                if (today == score) setBackgroundResource(R.drawable.bg_chip)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { saveMood(score) }
            })
        }
        box.addView(rowV)
        val speak = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setBackgroundResource(R.drawable.bg_card)
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 14), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = UiKit.dp(this@MainActivity, 12) }
        }
        speak.addView(TextView(this).apply { text = tr("Speak your mood"); textSize = 17f; setTextColor(0xFFFFFFFF.toInt()) })
        speak.addView(TextView(this).apply { text = tr("Tell Shiro how you feel…"); textSize = 13f; setTextColor(0xFFA9B7F0.toInt()) })
        speak.addView(TextView(this).apply {
            text = "🎙"; textSize = 28f; gravity = Gravity.CENTER; setBackgroundResource(R.drawable.bg_mic); contentDescription = tr("Talk to Shiro")
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 76), UiKit.dp(this@MainActivity, 76)).apply { topMargin = UiKit.dp(this@MainActivity, 10) }
            setOnClickListener { onTalk() }
        })
        box.addView(speak)
        box.addView(UiKit.section(this, tr("Recent Mood")))
        val (scores, labels) = stores.lastWeek()
        val chart = MoodChartView(this).apply {
            this.scores = scores; this.labels = labels; setBackgroundResource(R.drawable.bg_card)
            layoutParams = LinearLayout.LayoutParams(-1, UiKit.dp(this@MainActivity, 170)).apply { bottomMargin = UiKit.dp(this@MainActivity, 12) }
        }
        box.addView(chart)
        val recent = scores.filterNotNull().takeLast(3)
        val msg = when {
            recent.isEmpty() -> tr("Tap how you feel to start your mood tracker.")
            recent.size >= 2 && recent.average() <= 2.5 -> tr("You've had a few tough days. That's okay. Tomorrow is a new day.")
            else -> tr("Thank you for checking in. Noticing how you feel is a kind thing to do for yourself.")
        }
        box.addView(TextView(this).apply {
            text = "💛  $msg"; textSize = 14f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundResource(R.drawable.bg_card)
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 14), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 14))
        })
    }

    private fun saveMood(score: Int) {
        stores.setMood(score)
        buildMood()
        if (score <= 1) {
            AlertDialog.Builder(this).setTitle(tr("I'm sorry today feels heavy"))
                .setMessage(tr("You don't have to carry it alone. Would you like to talk, or see people you can reach?"))
                .setPositiveButton(tr("Talk to Shiro")) { _, _ -> onTalk() }
                .setNeutralButton(tr("People who can help")) { _, _ -> showHelplines() }
                .setNegativeButton(tr("Not now"), null).show()
        }
    }

    private fun buildGrowth() {
        val box = findViewById<LinearLayout>(R.id.growthBox); box.removeAllViews()
        box.addView(UiKit.title(this, tr("Your Growth"), tr("Small steps. Big changes.")))
        box.addView(UiKit.row(this, "🌿", tr("Self Care Goals"), tr("Build healthy habits")) { goalsDialog() })
        box.addView(UiKit.row(this, "🎙", tr("Personal Journal"), tr("Share your thoughts (voice)")) { noteMenu("journal", tr("Personal Journal")) })
        box.addView(UiKit.row(this, "💗", tr("Gratitude"), tr("Notice the good")) { noteMenu("gratitude", tr("Gratitude")) })
        box.addView(UiKit.row(this, "📈", tr("Progress"), tr("See how far you've come")) { progressDialog() })
        box.addView(UiKit.row(this, "👥", tr("Human Connections"), tr("Stronger relationships")) { contactsDialog() })
        box.addView(TextView(this).apply {
            text = tr("You are not just surviving,\nyou are growing."); textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt())
            setBackgroundResource(R.drawable.bg_card)
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 40), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 40))
        })
    }

    private val speedNames = listOf("Slow", "Normal", "Fast")

    private fun buildSettings() {
        val box = findViewById<LinearLayout>(R.id.settingsBox); box.removeAllViews()
        box.addView(UiKit.title(this, tr("Settings"), tr("Make Shiro yours")))
        box.addView(UiKit.section(this, tr("Voice Assistant")))
        box.addView(UiKit.row(this, "🎙", tr("Voice Style"), tr("Calm & Friendly")) {
            AlertDialog.Builder(this).setTitle(tr("Voice Style"))
                .setMessage(tr("Shiro speaks with a calm voice. Each language has its own open-source voice, so the voice changes with the language."))
                .setPositiveButton(tr("OK"), null).show()
        })
        box.addView(UiKit.row(this, "🌐", tr("Language"), lang.label) { showLanguagePicker() })
        box.addView(UiKit.row(this, "⏱", tr("Speech Speed"), tr(speedNames[prefs.getInt("speed", 1)])) {
            AlertDialog.Builder(this).setTitle(tr("Speech Speed"))
                .setSingleChoiceItems(speedNames.map { tr(it) }.toTypedArray(), prefs.getInt("speed", 1)) { d, i -> prefs.edit().putInt("speed", i).apply(); d.dismiss(); buildSettings() }
                .show()
        })
        val sw = Switch(this).apply {
            isChecked = captionsOn()
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("captions", on).apply() }
        }
        box.addView(UiKit.row(this, "▤", tr("Captions (Optional)"), tr("Show what you and Shiro say"), sw) { sw.toggle() })
        box.addView(UiKit.section(this, tr("App Preferences")))
        box.addView(UiKit.row(this, "🔒", tr("Privacy & Data"), tr("Your trust matters")) { privacyDialog() })
        box.addView(UiKit.row(this, "🌍", tr("Internet search"), if (searchOn()) tr("On") else tr("Off")) {
            if (searchOn()) { prefs.edit().putString("search", "off").apply(); buildSettings() }
            else showSearchConsent { ok -> prefs.edit().putString("search", if (ok) "on" else "off").apply(); buildSettings() }
        })
        val remNames = listOf(tr("Off"), tr("Morning (9:00)"), tr("Evening (20:00)"))
        val remHours = listOf(-1, 9, 20)
        val remIdx = remHours.indexOf(prefs.getInt(Reminders.PREF, -1)).let { if (it < 0) 0 else it }
        box.addView(UiKit.row(this, "🔔", tr("Notifications"), Tr.f("Gentle reminders: %s", remNames[remIdx])) {
            AlertDialog.Builder(this).setTitle(tr("Gentle reminder"))
                .setSingleChoiceItems(remNames.toTypedArray(), remIdx) { d, i ->
                    prefs.edit().putInt(Reminders.PREF, remHours[i]).apply()
                    if (remHours[i] >= 0) askNotificationPermission()
                    Reminders.schedule(this, remHours[i])
                    d.dismiss(); buildSettings()
                }.show()
        })
        box.addView(UiKit.row(this, "❓", tr("Help & Support"), tr("We're here for you")) {
            AlertDialog.Builder(this).setTitle(tr("Help & Support"))
                .setMessage(tr("Shiro is an AI companion. It is not a doctor or a therapist and cannot replace a real person.\n\nVersion 1.0"))
                .setPositiveButton(tr("Helplines")) { _, _ -> showHelplines() }.setNegativeButton(tr("OK"), null).show()
        })
        box.addView(UiKit.row(this, "🛡", tr("Need immediate help?"), tr("Tap to get crisis support")) { showHelplines() })
    }

    private fun privacyDialog() {
        AlertDialog.Builder(this).setTitle(tr("Privacy & Data"))
            .setMessage(tr("Shiro runs on your phone. Your voice is processed on the device and is never uploaded. The only thing sent over the internet is the words of a search question, and only when you ask Shiro to search and have allowed it. Mood, notes, goals and contacts are stored only on this phone."))
            .setPositiveButton(tr("OK"), null)
            .setNegativeButton(tr("Delete my saved data")) { _, _ ->
                AlertDialog.Builder(this).setTitle(tr("Delete saved data?"))
                    .setMessage(tr("This removes your mood history, journal, gratitude notes, goals, contacts and progress from this phone."))
                    .setPositiveButton(tr("Delete")) { _, _ -> stores.deleteAll(); Toast.makeText(this, tr("Deleted"), Toast.LENGTH_SHORT).show() }
                    .setNegativeButton(tr("Cancel"), null).show()
            }.show()
    }

    // ================= growth dialogs =================

    private fun askText(title: String, hint: String, inputType: Int = InputType.TYPE_CLASS_TEXT, onOk: (String) -> Unit) {
        val et = EditText(this).apply { this.hint = hint; this.inputType = inputType; setPadding(48, 32, 48, 32) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton(tr("OK")) { _, _ -> et.text.toString().trim().takeIf { it.isNotEmpty() }?.let(onOk) }
            .setNegativeButton(tr("Cancel"), null).show()
    }

    private fun goalsDialog() {
        val g = stores.goals().toMutableList()
        AlertDialog.Builder(this).setTitle(tr("Self Care Goals"))
            .setMultiChoiceItems(g.map { it.first }.toTypedArray(), g.map { it.second }.toBooleanArray()) { _, i, checked -> g[i] = g[i].first to checked }
            .setPositiveButton(tr("Save")) { _, _ -> stores.setGoals(g); stores.markActive() }
            .setNeutralButton(tr("Add goal")) { _, _ ->
                stores.setGoals(g)
                askText(tr("New goal"), tr("For example: stretch for 5 minutes")) { t -> stores.setGoals(g + (t to false)); goalsDialog() }
            }
            .setNegativeButton(tr("Remove ticked")) { _, _ -> stores.setGoals(g.filter { !it.second }) }
            .show()
    }

    private fun noteMenu(kind: String, title: String) {
        AlertDialog.Builder(this).setTitle(title)
            .setItems(arrayOf(tr("Add by voice"), tr("Read my entries"), tr("Delete all entries"))) { _, i ->
                when (i) {
                    0 -> recordNote(kind, title)
                    1 -> {
                        val n = stores.notes(kind)
                        AlertDialog.Builder(this).setTitle(title)
                            .setMessage(if (n.isEmpty()) tr("Nothing here yet.") else n.joinToString("\n\n"))
                            .setPositiveButton(tr("OK"), null).show()
                    }
                    else -> AlertDialog.Builder(this).setTitle(tr("Delete all entries?"))
                        .setPositiveButton(tr("Delete")) { _, _ -> stores.clearNotes(kind) }.setNegativeButton(tr("Cancel"), null).show()
                }
            }.show()
    }

    private fun recordNote(kind: String, title: String) {
        if (running || recording || downloading) return
        if (!ModelStore.ready(this, lang)) { Toast.makeText(this, tr("Finish Shiro's download first."), Toast.LENGTH_LONG).show(); return }
        withMic {
            recording = true
            val cancel = AtomicBoolean(false)
            val dlg = AlertDialog.Builder(this).setTitle(tr("Listening…"))
                .setMessage(tr("Speak your note. I'll stop when you pause."))
                .setCancelable(false).setNegativeButton(tr("Cancel")) { _, _ -> cancel.set(true) }.show()
            Thread {
                var text: String? = null; var err: String? = null
                try {
                    Engine.prepare(this, lang)
                    val audio = mic.capture { cancel.get() || destroyed }
                    if (audio != null) text = Engine.ears!!.transcribe(audio)
                } catch (t: Throwable) { err = Tr.f("Could not record: %s", t.message ?: t.javaClass.simpleName) }
                recording = false
                if (!destroyed) runOnUiThread {
                    dlg.dismiss()
                    val heard: String = text ?: ""
                    when {
                        err != null -> Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                        cancel.get() -> {}
                        heard.isBlank() || TextUtil.isLikelyNoise(heard) -> Toast.makeText(this, tr("I didn't hear anything."), Toast.LENGTH_SHORT).show()
                        else -> {
                            stores.addNote(kind, heard)
                            Toast.makeText(this, Tr.f("Saved to %s", title), Toast.LENGTH_SHORT).show()
                            if (Safety.isCrisis(heard, lang)) showHelplines()
                        }
                    }
                }
            }.start()
        }
    }

    private fun progressDialog() {
        AlertDialog.Builder(this).setTitle(tr("Your progress"))
            .setMessage(Tr.f("Days you checked in: %d\nCurrent streak: %d day(s)\nConversations with Shiro: %d\nJournal entries: %d\nGratitude notes: %d\n\nEvery check-in is a small step. Well done.", stores.checkInDays(), stores.streak(), stores.sessions(), stores.notes("journal").size, stores.notes("gratitude").size))
            .setPositiveButton(tr("OK"), null).show()
    }

    private fun contactsDialog() {
        val c = stores.contacts()
        val items = c.map { "${it.first}   ${it.second}" } + tr("➕ Add someone I trust")
        AlertDialog.Builder(this).setTitle(tr("Human Connections"))
            .setItems(items.toTypedArray()) { _, i ->
                if (i < c.size) {
                    AlertDialog.Builder(this).setTitle(c[i].first)
                        .setPositiveButton(tr("Call")) { _, _ -> dial(c[i].second) }
                        .setNeutralButton(tr("Remove")) { _, _ -> stores.setContacts(c.filterIndexed { j, _ -> j != i }) }
                        .setNegativeButton(tr("Back"), null).show()
                } else {
                    askText(tr("Name"), tr("Who can you reach out to?")) { name ->
                        askText(tr("Phone number"), tr("Number"), InputType.TYPE_CLASS_PHONE) { num -> stores.setContacts(c + (name to num)) }
                    }
                }
            }.setNegativeButton(tr("Close"), null).show()
    }

    // ================= language =================

    private fun showLanguagePicker() {
        if (running || downloading) return
        val all = Languages.all
        val labels = all.map { it.label + if (ModelStore.voiceReady(this, it.voice)) "" else "   ⬇" }
        AlertDialog.Builder(this).setTitle(tr("Language   (⬇ = voice download needed)"))
            .setSingleChoiceItems(labels.toTypedArray(), all.indexOf(lang)) { d, i -> d.dismiss(); chooseLanguage(all[i]) }
            .setNegativeButton(tr("Close"), null).show()
    }

    private fun chooseLanguage(l: Lang) {
        if (l.code != lang.code) {
            lang = l
            Tr.hindi = l.code == "hi"
            prefs.edit().putString("lang", l.code).apply()
            applyTexts(); rebuildStatic()
            Engine.brain?.clearHistory()
        }
        buildSettings(); refreshSetup()
        if (!l.llmGood) {
            AlertDialog.Builder(this).setTitle(l.label)
                .setMessage(Tr.f("Shiro listens and speaks %s, but the small on-device AI is weaker in this language, so replies may be simple or contain mistakes. It is strongest in English, Spanish, French, German, Italian, Portuguese, Russian, Arabic, Turkish, Vietnamese and Indonesian.", l.label))
                .setPositiveButton(tr("OK"), null).show()
        }
    }

    // ================= safety: repair, helplines, audio focus =================

    private fun showRepair(message: String, stage: String) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this).setTitle(tr("Shiro can't start"))
            .setMessage(message + "\n\n" + tr("A downloaded file may be damaged. Delete it and download it again?"))
            .setPositiveButton(tr("Repair")) { _, _ ->
                Thread {
                    Engine.release()
                    when (stage) {
                        "voice" -> ModelStore.deleteVoice(this, lang.voice)
                        "ears" -> ModelStore.whisperDir(this).deleteRecursively()
                        else -> ModelStore.llmFile(this).delete()
                    }
                    runOnUiThread { refreshSetup() }
                }.start()
            }.setNegativeButton(tr("Cancel"), null).show()
    }

    private fun requestAudioFocus() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener { c -> if (c == AudioManager.AUDIOFOCUS_LOSS || c == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) { running = false; Engine.mouth?.stop() } }
            .build()
        focusRequest = req
        am.requestAudioFocus(req)
    }

    private fun abandonAudioFocus() {
        val req = focusRequest ?: return
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(req)
        focusRequest = null
    }

    private fun showHelplines() {
        if (isFinishing || isDestroyed) return
        data class Item(val label: String, val action: () -> Unit)
        val items = ArrayList<Item>()
        val local = Helplines.forIso(Helplines.detectIso(this))
        if (local != null) items.add(Item("${local.country}: ${local.display}") { confirmCall(local) })
        items.add(Item(tr("Another country…")) { showCountryList() })
        items.add(Item(tr("Any country: findahelpline.com")) { openUrl("https://findahelpline.com") })
        items.add(Item(tr("Emergency: 112 (EU, India and many other countries)")) { dial("112") })
        items.add(Item(tr("Emergency: 911 (USA, Canada)")) { dial("911") })
        AlertDialog.Builder(this).setTitle(tr("You deserve support from a real person"))
            .setItems(items.map { it.label }.toTypedArray()) { _, i -> items[i].action() }
            .setNegativeButton(tr("Close"), null).show()
    }

    private fun showCountryList() {
        val list = Helplines.sortedByCountry
        AlertDialog.Builder(this).setTitle(tr("Choose your country"))
            .setItems(list.map { it.country }.toTypedArray()) { _, i -> confirmCall(list[i]) }
            .setNegativeButton(tr("Back")) { _, _ -> showHelplines() }.show()
    }

    private fun confirmCall(h: Helpline) {
        val note = if (h.note.isNotEmpty()) "\n${h.note}" else ""
        AlertDialog.Builder(this).setTitle(h.country).setMessage(Tr.f("Crisis line: %s", h.display) + note)
            .setPositiveButton(tr("Open dialer")) { _, _ -> dial(h.dial) }
            .setNegativeButton(tr("Back")) { _, _ -> showHelplines() }.show()
    }

    private fun dial(number: String) {
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))) }
        catch (_: Exception) { Toast.makeText(this, Tr.f("No phone app found. The number is %s", number), Toast.LENGTH_LONG).show() }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, Tr.f("No browser found. Visit %s", url), Toast.LENGTH_LONG).show() }
    }

    // ================= lifecycle =================

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.SPLASH, Screen.HOME -> super.onBackPressed()
            Screen.CONV -> endConversation()
            Screen.EXERCISE -> { stopExercise(); show(Screen.WELLNESS) }
            else -> show(Screen.HOME)
        }
    }

    override fun onStop() {
        // never keep the microphone or the sounds running in the background
        if (running) { running = false; Engine.mouth?.stop() }
        if (screen == Screen.EXERCISE && !soundExercise) { stopExercise(); show(Screen.WELLNESS) }
        super.onStop()
    }

    override fun onDestroy() {
        destroyed = true
        running = false
        if (isFinishing) stopExercise() else exTick?.let { handler.removeCallbacks(it) }
        Engine.mouth?.stop()
        super.onDestroy()
        if (isFinishing) Thread { loop?.join(3000); Engine.release() }.start()
    }
}
