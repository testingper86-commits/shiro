package com.shiro.companion

sealed class VoiceSpec {
    abstract val id: String
    abstract val approxMb: Int

    /** Piper voice converted for sherpa-onnx (k2-fsa "tts-models" release). Licences differ per voice. */
    data class Piper(val pack: String) : VoiceSpec() {
        override val id: String get() = "voice-$pack"
        override val approxMb: Int get() = 80
    }

    /** Meta MMS-TTS converted for sherpa-onnx. Licence CC-BY-NC 4.0 (non-commercial only). */
    data class Mms(val iso3: String) : VoiceSpec() {
        override val id: String get() = "voice-mms-$iso3"
        override val approxMb: Int get() = 115
    }
}

data class Lang(
    val code: String,          // Whisper language code
    val label: String,         // name shown in the picker
    val englishName: String,   // used in the LLM instruction
    val voice: VoiceSpec,      // which open-source TTS voice pack speaks this language
    val llmGood: Boolean,      // false = the 1.5B language model is weak in this language
    val greeting: String,
    val crisisReply: String,
    val crisisRegex: Regex,
    val tap: String,
    val loading: String,
    val listening: String,
    val thinking: String,
    val speaking: String,
    val searching: String,
    val noInternet: String,
    val searchFailed: String,
    val searchOff: String
)

object Languages {
    private val ic = RegexOption.IGNORE_CASE

    val all = listOf(
        Lang(
            code = "en", label = "English", englishName = "English", voice = VoiceSpec.Piper("vits-piper-en_US-amy-medium"), llmGood = true,
            greeting = "Hi, I'm Shiro. I'm here to listen. How are you feeling?",
            crisisReply = Safety.CRISIS_REPLY,
            crisisRegex = Regex("(?!)"), // English patterns are always checked in Safety
            tap = "Tap Shiro to talk", loading = "Waking Shiro up…", listening = "I'm listening…",
            thinking = "Thinking…", speaking = "Shiro is talking (tap to stop)",
            searching = "Searching the internet…", noInternet = "I can't reach the internet right now, so I can't look that up.",
            searchFailed = "I couldn't find a clear answer online. Could you ask in a different way?", searchOff = "Internet search is turned off. You can turn it on with the Internet button."
        ),
        Lang(
            code = "hi", label = "हिन्दी (Hindi)", englishName = "Hindi", voice = VoiceSpec.Piper("vits-piper-hi_IN-priyamvada-medium"), llmGood = false,
            greeting = "नमस्ते, मैं शिरो हूँ। मैं आपकी बात सुनने के लिए यहाँ हूँ। आप कैसा महसूस कर रहे हैं?",
            crisisReply = "मुझे खुशी है कि आपने मुझे बताया, और मुझे आपकी चिंता है। आप इस समय किसी असली इंसान के सहारे के हकदार हैं। " +
                "कृपया किसी भरोसेमंद व्यक्ति से बात करें या हेल्पलाइन पर फ़ोन करें। स्क्रीन पर लाल मदद बटन दबाइए। " +
                "अगर आपको लगता है कि आप खुद को नुकसान पहुँचा सकते हैं, तो अभी अपने आपातकालीन नंबर पर कॉल करें। " +
                "मैं यहीं हूँ और सुनती रहूँगी, पर कृपया किसी से संपर्क भी कीजिए।",
            crisisRegex = Regex(
                "मर\\s*(जाना|ना)\\s*चाह|आत्महत्या|खुदकुशी|आत्मघात|जान\\s*दे|जीना\\s*नहीं\\s*चाह|जीने\\s*का\\s*मन\\s*नहीं|" +
                    "खुद\\s*को\\s*(खत्म|ख़त्म|नुकसान|मार|चोट)|जीने\\s*की\\s*इच्छा\\s*नहीं|मर\\s*जाऊँ|मर\\s*जाऊं", ic
            ),
            tap = "बात करने के लिए शिरो को टैप करें", loading = "शिरो को जगा रहे हैं…", listening = "मैं सुन रही हूँ…",
            thinking = "सोच रही हूँ…", speaking = "शिरो बोल रही है (रोकने के लिए टैप करें)",
            searching = "इंटरनेट पर खोज रही हूँ…", noInternet = "अभी इंटरनेट नहीं चल रहा, इसलिए मैं यह खोज नहीं सकती।",
            searchFailed = "मुझे ऑनलाइन साफ़ जवाब नहीं मिला। क्या आप दूसरे तरीके से पूछ सकते हैं?", searchOff = "इंटरनेट खोज बंद है। आप इंटरनेट बटन से इसे चालू कर सकते हैं।"
        ),
        Lang(
            code = "es", label = "Español", englishName = "Spanish", voice = VoiceSpec.Piper("vits-piper-es_ES-davefx-medium"), llmGood = true,
            greeting = "Hola, soy Shiro. Estoy aquí para escucharte. ¿Cómo te sientes?",
            crisisReply = "Me alegra que me lo hayas contado, y me preocupas. Mereces el apoyo de una persona real ahora mismo. " +
                "Por favor, habla con alguien de confianza o llama a una línea de ayuda. Toca el botón rojo de ayuda en tu pantalla. " +
                "Si crees que podrías actuar según esos pensamientos, llama ahora mismo a tu número de emergencias. " +
                "Sigo aquí y te sigo escuchando, pero por favor contacta también con alguien.",
            crisisRegex = Regex(
                "quiero\\s+morir|quiero\\s+morirme|suicid|quitarme\\s+la\\s+vida|acabar\\s+con\\s+(mi\\s+vida|todo)|" +
                    "no\\s+quiero\\s+(vivir|seguir\\s+viviendo)|hacerme\\s+daño|matarme|no\\s+vale\\s+la\\s+pena\\s+vivir|autolesi", ic
            ),
            tap = "Toca a Shiro para hablar", loading = "Despertando a Shiro…", listening = "Te escucho…",
            thinking = "Pensando…", speaking = "Shiro está hablando (toca para parar)",
            searching = "Buscando en internet…", noInternet = "Ahora mismo no tengo internet, así que no puedo buscarlo.",
            searchFailed = "No encontré una respuesta clara en internet. ¿Puedes preguntarlo de otra forma?", searchOff = "La búsqueda en internet está desactivada. Puedes activarla con el botón de internet."
        ),
        Lang(
            code = "fr", label = "Français", englishName = "French", voice = VoiceSpec.Piper("vits-piper-fr_FR-siwis-medium"), llmGood = true,
            greeting = "Bonjour, je suis Shiro. Je suis là pour t'écouter. Comment te sens-tu ?",
            crisisReply = "Je suis contente que tu me l'aies dit, et je m'inquiète pour toi. Tu mérites le soutien d'une vraie personne maintenant. " +
                "Parle à quelqu'un de confiance ou appelle une ligne d'aide. Appuie sur le bouton rouge d'aide à l'écran. " +
                "Si tu penses pouvoir passer à l'acte, appelle tout de suite ton numéro d'urgence. " +
                "Je reste là et je continue de t'écouter, mais contacte aussi quelqu'un, s'il te plaît.",
            crisisRegex = Regex(
                "veux\\s+mourir|suicid|mettre\\s+fin\\s+à\\s+(ma\\s+vie|mes\\s+jours)|me\\s+tuer|ne\\s+veux\\s+plus\\s+vivre|" +
                    "me\\s+faire\\s+du\\s+mal|en\\s+finir|me\\s+blesser", ic
            ),
            tap = "Touche Shiro pour parler", loading = "Réveil de Shiro…", listening = "Je t'écoute…",
            thinking = "Je réfléchis…", speaking = "Shiro parle (touche pour arrêter)",
            searching = "Recherche sur internet…", noInternet = "Je n'ai pas internet en ce moment, donc je ne peux pas chercher ça.",
            searchFailed = "Je n'ai pas trouvé de réponse claire en ligne. Peux-tu demander autrement ?", searchOff = "La recherche sur internet est désactivée. Tu peux l'activer avec le bouton internet."
        ),
        Lang(
            code = "it", label = "Italiano", englishName = "Italian", voice = VoiceSpec.Piper("vits-piper-it_IT-paola-medium"), llmGood = true,
            greeting = "Ciao, sono Shiro. Sono qui per ascoltarti. Come ti senti?",
            crisisReply = "Sono contenta che tu me l'abbia detto, e sono preoccupata per te. Meriti il sostegno di una persona reale proprio ora. " +
                "Per favore parla con qualcuno di cui ti fidi o chiama una linea di aiuto. Tocca il pulsante rosso di aiuto sullo schermo. " +
                "Se pensi di poter agire su questi pensieri, chiama subito il numero di emergenza. " +
                "Io sono qui e continuo ad ascoltarti, ma contatta anche qualcuno, per favore.",
            crisisRegex = Regex(
                "voglio\\s+morire|suicid|togliermi\\s+la\\s+vita|farla\\s+finita|uccidermi|non\\s+voglio\\s+più\\s+vivere|" +
                    "farmi\\s+del\\s+male|autolesion", ic
            ),
            tap = "Tocca Shiro per parlare", loading = "Sto svegliando Shiro…", listening = "Ti ascolto…",
            thinking = "Sto pensando…", speaking = "Shiro sta parlando (tocca per fermare)",
            searching = "Cerco su internet…", noInternet = "Al momento non ho internet, quindi non posso cercarlo.",
            searchFailed = "Non ho trovato una risposta chiara online. Puoi chiedere in un altro modo?", searchOff = "La ricerca su internet è disattivata. Puoi attivarla con il pulsante internet."
        ),
        Lang(
            code = "pt", label = "Português", englishName = "Portuguese", voice = VoiceSpec.Piper("vits-piper-pt_BR-faber-medium"), llmGood = true,
            greeting = "Olá, eu sou a Shiro. Estou aqui para te ouvir. Como você está se sentindo?",
            crisisReply = "Fico feliz por você ter me contado, e estou preocupada com você. Você merece o apoio de uma pessoa de verdade agora. " +
                "Por favor, fale com alguém de confiança ou ligue para uma linha de ajuda. Toque no botão vermelho de ajuda na tela. " +
                "Se você acha que pode agir com base nesses pensamentos, ligue agora para o número de emergência. " +
                "Continuo aqui ouvindo você, mas, por favor, procure alguém também.",
            crisisRegex = Regex(
                "quero\\s+morrer|suic[ií]d|tirar\\s+(a\\s+)?minha\\s+vida|me\\s+matar|n[ãa]o\\s+quero\\s+mais\\s+viver|" +
                    "me\\s+machucar|acabar\\s+com\\s+(tudo|a\\s+minha\\s+vida|minha\\s+vida)|automutila", ic
            ),
            tap = "Toque na Shiro para falar", loading = "Acordando a Shiro…", listening = "Estou ouvindo…",
            thinking = "Pensando…", speaking = "Shiro está falando (toque para parar)",
            searching = "Pesquisando na internet…", noInternet = "No momento estou sem internet, então não posso pesquisar isso.",
            searchFailed = "Não encontrei uma resposta clara online. Pode perguntar de outro jeito?", searchOff = "A pesquisa na internet está desativada. Você pode ativá-la com o botão de internet."
        ),
        Lang(
            code = "de", label = "Deutsch", englishName = "German", voice = VoiceSpec.Piper("vits-piper-de_DE-thorsten-medium"), llmGood = true,
            greeting = "Hallo, ich bin Shiro. Ich bin da, um dir zuzuhören. Wie fühlst du dich?",
            crisisReply = "Ich bin froh, dass du es mir sagst, und ich mache mir Sorgen um dich. Du verdienst jetzt die Unterstützung eines echten Menschen. Bitte sprich mit jemandem, dem du vertraust, oder ruf eine Hilfetelefon-Nummer an. Tippe auf den roten Hilfe-Knopf auf dem Bildschirm. Wenn du denkst, dass du dir etwas antun könntest, ruf bitte sofort den Notruf an. Ich bleibe hier und höre dir weiter zu, aber bitte melde dich auch bei jemandem.",
            crisisRegex = Regex("will sterben|suizid|selbstmord|umbringen|das leben nehmen|nicht mehr leben|mich verletzen|mir etwas antun|ritzen|nicht mehr weiterleben", ic),
            tap = "Tippe auf Shiro, um zu sprechen", loading = "Shiro wacht auf…", listening = "Ich höre zu…",
            thinking = "Ich denke nach…", speaking = "Shiro spricht (zum Stoppen tippen)",
            searching = "Ich suche im Internet…", noInternet = "Ich habe gerade kein Internet, deshalb kann ich das nicht nachschlagen.",
            searchFailed = "Ich habe online keine klare Antwort gefunden. Kannst du es anders fragen?", searchOff = "Die Internetsuche ist ausgeschaltet. Du kannst sie mit dem Internet-Knopf einschalten."
        ),
        Lang(
            code = "ru", label = "Русский", englishName = "Russian", voice = VoiceSpec.Piper("vits-piper-ru_RU-irina-medium"), llmGood = true,
            greeting = "Привет, я Широ. Я здесь, чтобы тебя выслушать. Как ты себя чувствуешь?",
            crisisReply = "Я рада, что ты поделился этим со мной, и я переживаю за тебя. Тебе сейчас нужна поддержка настоящего человека. Пожалуйста, поговори с кем-то, кому ты доверяешь, или позвони на линию помощи. Нажми красную кнопку помощи на экране. Если ты думаешь, что можешь причинить себе вред, пожалуйста, прямо сейчас позвони в службу экстренной помощи. Я остаюсь рядом и продолжаю слушать, но, пожалуйста, обратись и к кому-то ещё.",
            crisisRegex = Regex("хочу умереть|суицид|самоубийств|убить себя|покончить с собой|не хочу жить|причинить себе вред|порезать себя|лучше бы меня не было", ic),
            tap = "Нажми на Широ, чтобы говорить", loading = "Широ просыпается…", listening = "Я слушаю…",
            thinking = "Думаю…", speaking = "Широ говорит (нажми, чтобы остановить)",
            searching = "Ищу в интернете…", noInternet = "Сейчас нет интернета, поэтому я не могу это найти.",
            searchFailed = "Я не нашла чёткого ответа в интернете. Можешь спросить по-другому?", searchOff = "Поиск в интернете выключен. Ты можешь включить его кнопкой интернета."
        ),
        Lang(
            code = "ar", label = "العربية", englishName = "Arabic", voice = VoiceSpec.Piper("vits-piper-ar_JO-kareem-medium"), llmGood = true,
            greeting = "مرحباً، أنا شيرو. أنا هنا لأسمعك. كيف حالك اليوم؟",
            crisisReply = "أنا سعيدة لأنك أخبرتني، وأنا قلقة عليك. أنت تستحق دعم شخص حقيقي الآن. من فضلك تحدث مع شخص تثق به أو اتصل بخط مساعدة. اضغط على زر المساعدة الأحمر على الشاشة. وإذا كنت تعتقد أنك قد تؤذي نفسك، فاتصل برقم الطوارئ الآن. سأبقى هنا وأستمع إليك، لكن من فضلك تواصل مع شخص آخر أيضاً.",
            crisisRegex = Regex("أريد أن أموت|اريد ان اموت|انتحار|أنهي حياتي|انهي حياتي|أقتل نفسي|اقتل نفسي|لا أريد أن أعيش|لا اريد ان اعيش|أؤذي نفسي|اؤذي نفسي|أريد الموت|اريد الموت", ic),
            tap = "اضغط على شيرو لتتحدث", loading = "جارٍ إيقاظ شيرو…", listening = "أنا أستمع…",
            thinking = "أفكر…", speaking = "شيرو تتحدث (اضغط للإيقاف)",
            searching = "أبحث في الإنترنت…", noInternet = "لا يوجد اتصال بالإنترنت الآن، لذلك لا أستطيع البحث.",
            searchFailed = "لم أجد إجابة واضحة على الإنترنت. هل يمكنك السؤال بطريقة أخرى؟", searchOff = "البحث في الإنترنت متوقف. يمكنك تشغيله بزر الإنترنت."
        ),
        Lang(
            code = "tr", label = "Türkçe", englishName = "Turkish", voice = VoiceSpec.Piper("vits-piper-tr_TR-dfki-medium"), llmGood = true,
            greeting = "Merhaba, ben Shiro. Seni dinlemek için buradayım. Nasıl hissediyorsun?",
            crisisReply = "Bana anlattığın için memnunum ve senin için endişeleniyorum. Şu anda gerçek bir insanın desteğini hak ediyorsun. Lütfen güvendiğin biriyle konuş ya da bir yardım hattını ara. Ekrandaki kırmızı yardım düğmesine dokun. Kendine zarar verebileceğini düşünüyorsan, lütfen hemen acil durum numarasını ara. Buradayım ve dinlemeye devam edeceğim, ama lütfen başka birine de ulaş.",
            crisisRegex = Regex("ölmek istiyorum|intihar|kendimi öldür|hayatıma son|yaşamak istemiyorum|kendime zarar|kendimi kes", ic),
            tap = "Konuşmak için Shiro'ya dokun", loading = "Shiro uyanıyor…", listening = "Dinliyorum…",
            thinking = "Düşünüyorum…", speaking = "Shiro konuşuyor (durdurmak için dokun)",
            searching = "İnternette arıyorum…", noInternet = "Şu an internetim yok, bu yüzden bunu araştıramam.",
            searchFailed = "İnternette net bir cevap bulamadım. Başka türlü sorabilir misin?", searchOff = "İnternet araması kapalı. İnternet düğmesiyle açabilirsin."
        ),
        Lang(
            code = "vi", label = "Tiếng Việt", englishName = "Vietnamese", voice = VoiceSpec.Piper("vits-piper-vi_VN-vais1000-medium"), llmGood = true,
            greeting = "Xin chào, mình là Shiro. Mình ở đây để lắng nghe bạn. Bạn đang cảm thấy thế nào?",
            crisisReply = "Mình rất mừng vì bạn đã chia sẻ, và mình lo cho bạn. Bạn xứng đáng nhận được sự hỗ trợ từ một người thật ngay bây giờ. Hãy nói chuyện với người bạn tin tưởng hoặc gọi đường dây hỗ trợ. Hãy chạm vào nút trợ giúp màu đỏ trên màn hình. Nếu bạn nghĩ mình có thể làm hại bản thân, hãy gọi số khẩn cấp ngay. Mình vẫn ở đây và tiếp tục lắng nghe, nhưng hãy liên hệ với ai đó nữa nhé.",
            crisisRegex = Regex("muốn chết|tự tử|tự sát|kết thúc cuộc sống|không muốn sống|làm hại bản thân|tự làm đau mình", ic),
            tap = "Chạm vào Shiro để nói chuyện", loading = "Đang đánh thức Shiro…", listening = "Mình đang nghe…",
            thinking = "Đang suy nghĩ…", speaking = "Shiro đang nói (chạm để dừng)",
            searching = "Đang tìm trên internet…", noInternet = "Hiện không có internet nên mình không tra cứu được.",
            searchFailed = "Mình không tìm thấy câu trả lời rõ ràng trên mạng. Bạn thử hỏi cách khác nhé?", searchOff = "Tìm kiếm internet đang tắt. Bạn có thể bật bằng nút Internet."
        ),
        Lang(
            code = "id", label = "Bahasa Indonesia", englishName = "Indonesian", voice = VoiceSpec.Piper("vits-piper-id_ID-news_tts-medium"), llmGood = true,
            greeting = "Halo, aku Shiro. Aku di sini untuk mendengarkanmu. Bagaimana perasaanmu?",
            crisisReply = "Aku senang kamu menceritakannya, dan aku khawatir padamu. Kamu pantas mendapat dukungan dari orang sungguhan sekarang. Tolong bicara dengan orang yang kamu percaya atau hubungi layanan bantuan. Ketuk tombol bantuan merah di layar. Jika kamu merasa bisa menyakiti dirimu, tolong segera hubungi nomor darurat. Aku tetap di sini dan terus mendengarkan, tapi tolong hubungi seseorang juga.",
            crisisRegex = Regex("ingin mati|bunuh diri|mengakhiri hidup|tidak ingin hidup|tak ingin hidup|menyakiti diri|melukai diri|ingin menghilang", ic),
            tap = "Ketuk Shiro untuk bicara", loading = "Membangunkan Shiro…", listening = "Aku mendengarkan…",
            thinking = "Sedang berpikir…", speaking = "Shiro sedang bicara (ketuk untuk berhenti)",
            searching = "Mencari di internet…", noInternet = "Aku sedang tidak punya internet, jadi tidak bisa mencarinya.",
            searchFailed = "Aku tidak menemukan jawaban yang jelas di internet. Bisa tanya dengan cara lain?", searchOff = "Pencarian internet dimatikan. Kamu bisa menyalakannya dengan tombol Internet."
        ),
        Lang(
            code = "pl", label = "Polski", englishName = "Polish", voice = VoiceSpec.Piper("vits-piper-pl_PL-gosia-medium"), llmGood = false,
            greeting = "Cześć, jestem Shiro. Jestem tu, żeby cię wysłuchać. Jak się czujesz?",
            crisisReply = "Dziękuję, że mi o tym mówisz, i martwię się o ciebie. Zasługujesz teraz na wsparcie prawdziwego człowieka. Porozmawiaj proszę z kimś, komu ufasz, albo zadzwoń na telefon zaufania. Dotknij czerwonego przycisku pomocy na ekranie. Jeśli myślisz, że możesz zrobić sobie krzywdę, zadzwoń od razu pod numer alarmowy. Zostaję tu i dalej słucham, ale proszę, skontaktuj się też z kimś.",
            crisisRegex = Regex("chcę umrzeć|chce umrzec|samobój|zabić się|zabic sie|skończyć z życiem|nie chcę żyć|nie chce zyc|zrobić sobie krzywdę|pociąć się", ic),
            tap = "Dotknij Shiro, aby mówić", loading = "Budzę Shiro…", listening = "Słucham…",
            thinking = "Myślę…", speaking = "Shiro mówi (dotknij, aby zatrzymać)",
            searching = "Szukam w internecie…", noInternet = "Nie mam teraz internetu, więc nie mogę tego sprawdzić.",
            searchFailed = "Nie znalazłam jasnej odpowiedzi w internecie. Czy możesz zapytać inaczej?", searchOff = "Wyszukiwanie w internecie jest wyłączone. Możesz je włączyć przyciskiem Internet."
        ),
        Lang(
            code = "ur", label = "اردو", englishName = "Urdu", voice = VoiceSpec.Piper("vits-piper-ur_PK-fasih-medium"), llmGood = false,
            greeting = "السلام علیکم، میں شیرو ہوں۔ میں آپ کی بات سننے کے لیے یہاں ہوں۔ آپ کیسا محسوس کر رہے ہیں؟",
            crisisReply = "مجھے خوشی ہے کہ آپ نے مجھے بتایا، اور مجھے آپ کی فکر ہے۔ آپ اس وقت کسی حقیقی انسان کے سہارے کے حق دار ہیں۔ براہِ کرم کسی بھروسہ مند شخص سے بات کریں یا ہیلپ لائن پر کال کریں۔ اسکرین پر سرخ مدد کا بٹن دبائیں۔ اگر آپ کو لگتا ہے کہ آپ خود کو نقصان پہنچا سکتے ہیں تو ابھی ہنگامی نمبر پر کال کریں۔ میں یہیں ہوں اور سنتی رہوں گی، لیکن براہِ کرم کسی اور سے بھی رابطہ کریں۔",
            crisisRegex = Regex("مرنا چاہتا|مرنا چاہتی|خودکشی|اپنی جان لے|جینا نہیں چاہتا|جینا نہیں چاہتی|خود کو نقصان|خود کو مار", ic),
            tap = "بات کرنے کے لیے شیرو کو ٹیپ کریں", loading = "شیرو کو جگایا جا رہا ہے…", listening = "میں سن رہی ہوں…",
            thinking = "سوچ رہی ہوں…", speaking = "شیرو بول رہی ہے (روکنے کے لیے ٹیپ کریں)",
            searching = "انٹرنیٹ پر تلاش کر رہی ہوں…", noInternet = "ابھی انٹرنیٹ نہیں ہے، اس لیے میں یہ تلاش نہیں کر سکتی۔",
            searchFailed = "مجھے آن لائن واضح جواب نہیں ملا۔ کیا آپ دوسرے طریقے سے پوچھ سکتے ہیں؟", searchOff = "انٹرنیٹ تلاش بند ہے۔ آپ اسے انٹرنیٹ بٹن سے چالو کر سکتے ہیں۔"
        ),
        Lang(
            code = "kn", label = "ಕನ್ನಡ", englishName = "Kannada", voice = VoiceSpec.Mms("kan"), llmGood = false,
            greeting = "ನಮಸ್ಕಾರ, ನಾನು ಶಿರೋ. ನಿಮ್ಮ ಮಾತು ಕೇಳಲು ನಾನು ಇಲ್ಲಿದ್ದೇನೆ. ನೀವು ಹೇಗಿದ್ದೀರಿ?",
            crisisReply = "ನೀವು ನನ್ನೊಂದಿಗೆ ಹೇಳಿಕೊಂಡಿದ್ದು ನನಗೆ ಸಂತೋಷ, ಮತ್ತು ನನಗೆ ನಿಮ್ಮ ಬಗ್ಗೆ ಚಿಂತೆಯಾಗಿದೆ. ನೀವು ಈಗ ನಿಜವಾದ ವ್ಯಕ್ತಿಯ ಬೆಂಬಲಕ್ಕೆ ಅರ್ಹರು. ದಯವಿಟ್ಟು ನಂಬಿಕೆಯ ವ್ಯಕ್ತಿಯೊಂದಿಗೆ ಮಾತನಾಡಿ ಅಥವಾ ಸಹಾಯವಾಣಿಗೆ ಕರೆ ಮಾಡಿ. ಪರದೆಯ ಮೇಲಿನ ಕೆಂಪು ಸಹಾಯ ಬಟನ್ ಒತ್ತಿ. ನಿಮಗೆ ನೀವೇ ಹಾನಿ ಮಾಡಿಕೊಳ್ಳಬಹುದು ಎಂದು ಅನಿಸಿದರೆ, ಈಗಲೇ ತುರ್ತು ಸಂಖ್ಯೆಗೆ ಕರೆ ಮಾಡಿ. ನಾನು ಇಲ್ಲೇ ಇದ್ದೇನೆ, ಕೇಳುತ್ತಲೇ ಇರುತ್ತೇನೆ, ಆದರೆ ದಯವಿಟ್ಟು ಬೇರೆಯವರನ್ನೂ ಸಂಪರ್ಕಿಸಿ.",
            crisisRegex = Regex("ಸಾಯಲು ಬಯಸ|ಆತ್ಮಹತ್ಯೆ|ಸಾಯಬೇಕು|ಜೀವನ ಮುಗಿಸ|ಬದುಕಲು ಇಷ್ಟವಿಲ್ಲ|ಬದುಕಬೇಕೆಂದು ಅನಿಸುತ್ತಿಲ್ಲ|ನನ್ನನ್ನು ನಾನೇ ಕೊಲ್ಲ|ಹಾನಿ ಮಾಡಿಕೊಳ್ಳ", ic),
            tap = "ಮಾತನಾಡಲು ಶಿರೋ ಮೇಲೆ ಒತ್ತಿ", loading = "ಶಿರೋ ಎಚ್ಚರವಾಗುತ್ತಿದೆ…", listening = "ನಾನು ಕೇಳುತ್ತಿದ್ದೇನೆ…",
            thinking = "ಯೋಚಿಸುತ್ತಿದ್ದೇನೆ…", speaking = "ಶಿರೋ ಮಾತನಾಡುತ್ತಿದೆ (ನಿಲ್ಲಿಸಲು ಒತ್ತಿ)",
            searching = "ಇಂಟರ್ನೆಟ್‌ನಲ್ಲಿ ಹುಡುಕುತ್ತಿದ್ದೇನೆ…", noInternet = "ಈಗ ಇಂಟರ್ನೆಟ್ ಇಲ್ಲ, ಹಾಗಾಗಿ ಹುಡುಕಲು ಆಗುತ್ತಿಲ್ಲ.",
            searchFailed = "ಆನ್‌ಲೈನ್‌ನಲ್ಲಿ ಸ್ಪಷ್ಟ ಉತ್ತರ ಸಿಗಲಿಲ್ಲ. ಬೇರೆ ರೀತಿ ಕೇಳುತ್ತೀರಾ?", searchOff = "ಇಂಟರ್ನೆಟ್ ಹುಡುಕಾಟ ಆಫ್ ಆಗಿದೆ. ಇಂಟರ್ನೆಟ್ ಬಟನ್‌ನಿಂದ ಆನ್ ಮಾಡಬಹುದು."
        ),
        Lang(
            code = "ta", label = "தமிழ்", englishName = "Tamil", voice = VoiceSpec.Mms("tam"), llmGood = false,
            greeting = "வணக்கம், நான் ஷிரோ. உங்கள் பேச்சைக் கேட்க நான் இங்கே இருக்கிறேன். நீங்கள் எப்படி உணர்கிறீர்கள்?",
            crisisReply = "நீங்கள் என்னிடம் சொன்னதற்கு நன்றி, உங்களைப் பற்றி எனக்குக் கவலையாக இருக்கிறது. இப்போது நீங்கள் ஒரு உண்மையான மனிதரின் ஆதரவுக்குத் தகுதியானவர். தயவுசெய்து நம்பிக்கையான ஒருவரிடம் பேசுங்கள் அல்லது உதவி எண்ணை அழையுங்கள். திரையில் உள்ள சிவப்பு உதவி பொத்தானைத் தொடுங்கள். உங்களுக்கு நீங்களே தீங்கு செய்துகொள்ளலாம் என்று தோன்றினால், உடனே அவசர எண்ணை அழையுங்கள். நான் இங்கேயே இருக்கிறேன், தொடர்ந்து கேட்பேன், ஆனால் தயவுசெய்து வேறொருவரையும் தொடர்பு கொள்ளுங்கள்.",
            crisisRegex = Regex("சாக வேண்டும்|சாக விரும்புகிறேன்|தற்கொலை|வாழ விரும்பவில்லை|உயிரை மாய்|என்னை நானே கொல்|வாழ்க்கையை முடி|தீங்கு செய்துகொள்", ic),
            tap = "பேச ஷிரோவைத் தொடுங்கள்", loading = "ஷிரோ எழுந்துகொள்கிறது…", listening = "நான் கேட்கிறேன்…",
            thinking = "யோசிக்கிறேன்…", speaking = "ஷிரோ பேசுகிறது (நிறுத்த தொடுங்கள்)",
            searching = "இணையத்தில் தேடுகிறேன்…", noInternet = "இப்போது இணையம் இல்லை, அதனால் தேட முடியாது.",
            searchFailed = "இணையத்தில் தெளிவான பதில் கிடைக்கவில்லை. வேறு விதமாகக் கேட்கிறீர்களா?", searchOff = "இணையத் தேடல் அணைக்கப்பட்டுள்ளது. இணைய பொத்தானால் இயக்கலாம்."
        ),
        Lang(
            code = "te", label = "తెలుగు", englishName = "Telugu", voice = VoiceSpec.Mms("tel"), llmGood = false,
            greeting = "నమస్కారం, నేను షిరో. మీ మాట వినడానికి నేను ఇక్కడ ఉన్నాను. మీరు ఎలా ఉన్నారు?",
            crisisReply = "మీరు నాతో చెప్పినందుకు ధన్యవాదాలు, మీ గురించి నాకు ఆందోళనగా ఉంది. మీరు ఇప్పుడు నిజమైన వ్యక్తి మద్దతుకు అర్హులు. దయచేసి మీరు నమ్మే వ్యక్తితో మాట్లాడండి లేదా హెల్ప్‌లైన్‌కు కాల్ చేయండి. స్క్రీన్‌పై ఉన్న ఎరుపు సహాయ బటన్‌ను నొక్కండి. మీకు మీరే హాని చేసుకోవచ్చని అనిపిస్తే, వెంటనే అత్యవసర నంబర్‌కు కాల్ చేయండి. నేను ఇక్కడే ఉన్నాను, వింటూనే ఉంటాను, కానీ దయచేసి మరొకరిని కూడా సంప్రదించండి.",
            crisisRegex = Regex("చనిపోవాలి|చావాలని|ఆత్మహత్య|బతకాలని లేదు|జీవితాన్ని ముగించ|నన్ను నేను చంపుకో|హాని చేసుకో", ic),
            tap = "మాట్లాడటానికి షిరోను తాకండి", loading = "షిరో మేల్కొంటోంది…", listening = "నేను వింటున్నాను…",
            thinking = "ఆలోచిస్తున్నాను…", speaking = "షిరో మాట్లాడుతోంది (ఆపడానికి తాకండి)",
            searching = "ఇంటర్నెట్‌లో వెతుకుతున్నాను…", noInternet = "ఇప్పుడు ఇంటర్నెట్ లేదు, అందుకే వెతకలేను.",
            searchFailed = "ఆన్‌లైన్‌లో స్పష్టమైన సమాధానం దొరకలేదు. మరో విధంగా అడగగలరా?", searchOff = "ఇంటర్నెట్ శోధన ఆఫ్‌లో ఉంది. ఇంటర్నెట్ బటన్‌తో ఆన్ చేయవచ్చు."
        ),
        Lang(
            code = "bn", label = "বাংলা", englishName = "Bengali", voice = VoiceSpec.Mms("ben"), llmGood = false,
            greeting = "নমস্কার, আমি শিরো। আপনার কথা শোনার জন্য আমি এখানে আছি। আপনি কেমন বোধ করছেন?",
            crisisReply = "আপনি আমাকে বলেছেন বলে ধন্যবাদ, আর আমি আপনার জন্য চিন্তিত। এখন আপনি একজন সত্যিকারের মানুষের সহায়তা পাওয়ার যোগ্য। দয়া করে বিশ্বাসযোগ্য কারও সঙ্গে কথা বলুন বা হেল্পলাইনে ফোন করুন। স্ক্রিনের লাল সাহায্য বোতামটি চাপুন। আপনার যদি মনে হয় আপনি নিজের ক্ষতি করতে পারেন, এখনই জরুরি নম্বরে ফোন করুন। আমি এখানেই আছি, শুনতে থাকব, কিন্তু দয়া করে আর কারও সঙ্গেও যোগাযোগ করুন।",
            crisisRegex = Regex("মরতে চাই|আত্মহত্যা|বাঁচতে চাই না|জীবন শেষ|নিজেকে শেষ|নিজের ক্ষতি|মরে যেতে চাই", ic),
            tap = "কথা বলতে শিরোকে ছুঁয়ে দিন", loading = "শিরো জেগে উঠছে…", listening = "আমি শুনছি…",
            thinking = "ভাবছি…", speaking = "শিরো কথা বলছে (থামাতে ছুঁয়ে দিন)",
            searching = "ইন্টারনেটে খুঁজছি…", noInternet = "এখন ইন্টারনেট নেই, তাই খুঁজতে পারছি না।",
            searchFailed = "অনলাইনে স্পষ্ট উত্তর পাইনি। অন্যভাবে জিজ্ঞাসা করবেন?", searchOff = "ইন্টারনেট সার্চ বন্ধ আছে। ইন্টারনেট বোতাম দিয়ে চালু করতে পারেন।"
        )
    )

    fun byCode(code: String?): Lang = all.firstOrNull { it.code == code } ?: all.first()
}
