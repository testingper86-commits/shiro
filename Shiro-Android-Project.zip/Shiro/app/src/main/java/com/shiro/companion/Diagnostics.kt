package com.shiro.companion

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File

/** Keeps the last crash on the phone so a problem can be understood from one report. No conversations are ever stored here. */
object CrashLog {
    private const val FILE = "last_crash.txt"

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(app.filesDir, FILE).writeText("${java.util.Date()}\n${Log.getStackTraceString(e).take(3500)}") } catch (_: Throwable) {}
            previous?.uncaughtException(t, e)
        }
    }

    fun last(ctx: Context): String? = File(ctx.filesDir, FILE).takeIf { it.exists() }?.readText()

    fun note(ctx: Context, message: String) {
        ctx.getSharedPreferences("shiro_diag", Context.MODE_PRIVATE).edit().putString("last_error", message.take(300)).apply()
    }

    fun lastError(ctx: Context): String? = ctx.getSharedPreferences("shiro_diag", Context.MODE_PRIVATE).getString("last_error", null)
}

object Diagnostics {
    /** A short technical report. It contains no conversations, notes, mood data or contacts. */
    fun report(ctx: Context, lang: Lang): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo(); am.getMemoryInfo(mem)
        val version = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Exception) { "?" }
        val offline = AppSettings.offlineVoice(ctx)
        val sb = StringBuilder()
        sb.appendLine("Shiro diagnostics (no conversations or personal data)")
        sb.appendLine("App version: $version")
        sb.appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}); device: ${Build.MANUFACTURER} ${Build.MODEL}; CPU: ${Build.SUPPORTED_ABIS.firstOrNull()}")
        sb.appendLine("Memory: ${mem.totalMem / 1_000_000} MB total, ${mem.availMem / 1_000_000} MB free; storage free: ${ctx.filesDir.usableSpace / 1_000_000} MB")
        sb.appendLine("Language: ${lang.code}; voice engine: ${if (offline) "offline open-source" else "phone"}; brain: ${if (AppSettings.bigBrain(ctx)) "large" else "small"}")
        sb.appendLine("Ready: brain=${ModelStore.brainReady(ctx)}, whisper=${ModelStore.whisperReady(ctx)}, voice=${ModelStore.voiceReady(ctx, lang.voice)}")
        sb.appendLine("Brain failure: ${Engine.brainFailure?.let { it.javaClass.simpleName + ": " + (it.message ?: "") } ?: "none"}")
        sb.appendLine("Last error: ${CrashLog.lastError(ctx) ?: "none"}")
        sb.appendLine("Last crash: ${CrashLog.last(ctx) ?: "none"}")
        return sb.toString()
    }
}
