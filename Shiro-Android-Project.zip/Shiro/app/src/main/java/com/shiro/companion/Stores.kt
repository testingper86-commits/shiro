package com.shiro.companion

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Everything the person saves stays on the phone (SharedPreferences). */
class Stores(ctx: Context) {
    private val p = ctx.getSharedPreferences("shiro_data", Context.MODE_PRIVATE)
    private val day = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private fun today() = day.format(Date())

    // --- mood: date -> score (1 Sad .. 5 Great)
    private fun moodMap(): JSONObject = try { JSONObject(p.getString("mood", "{}")) } catch (_: Exception) { JSONObject() }
    fun setMood(score: Int) {
        val m = moodMap(); m.put(today(), score)
        p.edit().putString("mood", m.toString()).apply(); markActive()
    }
    fun moodToday(): Int? = moodMap().optInt(today(), 0).takeIf { it in 1..5 }

    /** Last 7 days, oldest first, with weekday labels. */
    fun lastWeek(): Pair<List<Int?>, List<String>> {
        val m = moodMap(); val cal = Calendar.getInstance()
        val scores = ArrayList<Int?>(); val labels = ArrayList<String>()
        cal.add(Calendar.DAY_OF_YEAR, -6)
        repeat(7) {
            scores.add(m.optInt(day.format(cal.time), 0).takeIf { it in 1..5 })
            labels.add(SimpleDateFormat("EEE", Locale.getDefault()).format(cal.time))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return scores to labels
    }

    // --- active days / sessions (for Progress)
    fun markActive() {
        val a = activeDays().toMutableSet(); a.add(today())
        p.edit().putString("active", a.joinToString(",")).apply()
    }
    private fun activeDays(): Set<String> = p.getString("active", "")!!.split(",").filter { it.isNotEmpty() }.toSet()
    fun addSession() { p.edit().putInt("sessions", p.getInt("sessions", 0) + 1).apply(); markActive() }
    fun sessions() = p.getInt("sessions", 0)
    fun checkInDays() = activeDays().size
    fun streak(): Int {
        val a = activeDays(); val cal = Calendar.getInstance(); var n = 0
        if (day.format(cal.time) !in a) cal.add(Calendar.DAY_OF_YEAR, -1)   // today may not be done yet
        while (day.format(cal.time) in a) { n++; cal.add(Calendar.DAY_OF_YEAR, -1) }
        return n
    }

    // --- simple text lists: journal, gratitude, goals ("text" + "done"), trusted contacts ("name" + "number")
    private fun list(key: String): JSONArray = try { JSONArray(p.getString(key, "[]")) } catch (_: Exception) { JSONArray() }
    private fun save(key: String, a: JSONArray) = p.edit().putString(key, a.toString()).apply()

    fun addNote(kind: String, text: String) {
        val a = list(kind); a.put(JSONObject().put("date", today()).put("text", text)); save(kind, a); markActive()
    }
    fun notes(kind: String): List<String> =
        (0 until list(kind).length()).map { list(kind).getJSONObject(it) }.reversed().map { "${it.optString("date")}: ${it.optString("text")}" }

    fun clearNotes(kind: String) { p.edit().remove(kind).apply() }

    fun goals(): List<Pair<String, Boolean>> {
        if (!p.contains("goals")) {
            save("goals", JSONArray(listOf("Drink water", "Take a short walk", "Go to bed on time", "Talk to someone I trust").map { Tr.t(it) }
                .map { JSONObject().put("text", it).put("done", false) }))
        }
        return (0 until list("goals").length()).map { list("goals").getJSONObject(it) }.map { it.optString("text") to it.optBoolean("done") }
    }
    fun setGoals(g: List<Pair<String, Boolean>>) =
        save("goals", JSONArray(g.map { JSONObject().put("text", it.first).put("done", it.second) }))

    fun contacts(): List<Pair<String, String>> =
        (0 until list("contacts").length()).map { list("contacts").getJSONObject(it) }.map { it.optString("name") to it.optString("number") }
    fun setContacts(c: List<Pair<String, String>>) =
        save("contacts", JSONArray(c.map { JSONObject().put("name", it.first).put("number", it.second) }))

    fun deleteAll() { p.edit().clear().apply() }
}
