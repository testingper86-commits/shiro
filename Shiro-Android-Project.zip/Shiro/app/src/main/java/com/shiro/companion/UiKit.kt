package com.shiro.companion

import android.content.Context
import android.graphics.Outline
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** Small helpers that build the repeated card rows and tiles of the design in code. */
object UiKit {
    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /** The standard touch ripple, used as a foreground so rounded cards still show their look. */
    fun ripple(ctx: Context): android.graphics.drawable.Drawable? {
        val tv = android.util.TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return androidx.core.content.ContextCompat.getDrawable(ctx, tv.resourceId)
    }

    /** Small press-down animation for the round buttons. */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    private fun text(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = s; textSize = sp; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun title(ctx: Context, big: String, small: String, back: (() -> Unit)? = null): View {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (back != null) row.addView(text(ctx, "‹", 30f, 0xFFFFFFFF.toInt()).apply {
            gravity = Gravity.CENTER; contentDescription = "Back"
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 44), dp(ctx, 44)); setOnClickListener { back() }
        }) else row.addView(avatar(ctx, 48))
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(ctx, 10), 0, 0, 0) }
        col.addView(text(ctx, big, 22f, 0xFFFFFFFF.toInt()))
        col.addView(text(ctx, small, 13f, 0xFFA9B7F0.toInt()))
        row.addView(col)
        row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(ctx, 14) }
        return row
    }

    fun avatar(ctx: Context, size: Int) = ImageView(ctx).apply {
        setImageResource(R.drawable.shiro_logo); contentDescription = "Shiro"
        setBackgroundResource(R.drawable.bg_avatar)
        val p = dp(ctx, (size / 8).coerceAtLeast(3)); setPadding(p, p, p, p)
        layoutParams = LinearLayout.LayoutParams(dp(ctx, size), dp(ctx, size))
    }

    /** Rounded picture card with a dark fade, a title and an optional round button (landscape art from the design). */
    fun hero(ctx: Context, image: Int, title: String, sub: String, trailing: String?, heightDp: Int, onClick: (() -> Unit)?): View {
        val root = FrameLayout(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(ctx, heightDp)).apply { bottomMargin = dp(ctx, 12) }
            setBackgroundResource(R.drawable.bg_card)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(ctx, 20).toFloat()) }
            }
            clipToOutline = true
            if (onClick != null) { isClickable = true; isFocusable = true; setOnClickListener { onClick() } }
            foreground = ripple(ctx)
        }
        root.addView(ImageView(ctx).apply {
            setImageResource(image); scaleType = ImageView.ScaleType.CENTER_CROP
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        })
        root.addView(View(ctx).apply { setBackgroundResource(R.drawable.bg_scrim); layoutParams = FrameLayout.LayoutParams(-1, -1) })
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(ctx, 18), 0, dp(ctx, 80), dp(ctx, 16)) }
        }
        col.addView(text(ctx, title, 20f, 0xFFFFFFFF.toInt(), true))
        if (sub.isNotEmpty()) col.addView(text(ctx, sub, 13f, 0xFFD6DEFF.toInt()))
        root.addView(col)
        if (trailing != null) root.addView(text(ctx, trailing, 22f, 0xFFFFFFFF.toInt()).apply {
            gravity = Gravity.CENTER; setBackgroundResource(R.drawable.bg_circle_outline)
            layoutParams = FrameLayout.LayoutParams(dp(ctx, 48), dp(ctx, 48), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(ctx, 16), dp(ctx, 16)) }
        })
        return root
    }

    fun section(ctx: Context, s: String) = text(ctx, s, 15f, 0xFFFFFFFF.toInt(), true).apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 8); bottomMargin = dp(ctx, 8) }
    }

    /** Card row: round icon, title, subtitle, chevron (or a switch). */
    fun row(ctx: Context, icon: String, title: String, sub: String, sw: Switch? = null, onClick: (() -> Unit)? = null): View {
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_card); setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(ctx, 10) }
            isClickable = true; isFocusable = true
            if (onClick != null) setOnClickListener { onClick() }
            foreground = ripple(ctx)
        }
        r.addView(text(ctx, icon, 20f, 0xFFFFFFFF.toInt()).apply {
            gravity = Gravity.CENTER; setBackgroundResource(R.drawable.bg_row_icon)
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 44), dp(ctx, 44))
        })
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(ctx, 12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        col.addView(text(ctx, title, 15f, 0xFFFFFFFF.toInt(), true))
        col.addView(text(ctx, sub, 12f, 0xFFA9B7F0.toInt()))
        r.addView(col)
        r.addView(sw ?: text(ctx, "›", 24f, 0xFFA9B7F0.toInt()))
        return r
    }

    fun tile(ctx: Context, icon: String, title: String, sub: String, onClick: () -> Unit): View =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundResource(R.drawable.bg_card); setPadding(dp(ctx, 4), dp(ctx, 10), dp(ctx, 4), dp(ctx, 10))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(ctx, 4); marginEnd = dp(ctx, 4) }
            isClickable = true; isFocusable = true; setOnClickListener { onClick() }
            foreground = ripple(ctx)
            addView(text(ctx, icon, 26f, 0xFFFFFFFF.toInt()))
            addView(text(ctx, title, 14f, 0xFFFFFFFF.toInt()).apply { gravity = Gravity.CENTER })
            addView(text(ctx, sub, 10f, 0xFFA9B7F0.toInt()).apply { gravity = Gravity.CENTER })
        }

    fun bubble(ctx: Context, s: String, fromUser: Boolean): View = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = if (fromUser) Gravity.END else Gravity.START
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(ctx, 10) }
        if (!fromUser) addView(avatar(ctx, 36))
        addView(text(ctx, s, 15f, 0xFFFFFFFF.toInt()).apply {
            setBackgroundResource(R.drawable.bg_card); setPadding(dp(ctx, 14), dp(ctx, 10), dp(ctx, 14), dp(ctx, 10))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(ctx, 8); marginEnd = dp(ctx, 8) }
            maxWidth = dp(ctx, 270)
        })
    }
}
