package com.shiro.companion

import android.content.Context

/** Two switches that decide how big the download is and how fast Shiro feels. */
object AppSettings {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("shiro", Context.MODE_PRIVATE)

    /** true (default) = open-source Whisper + Piper/MMS; false = the phone's own speech recognition and voice (tiny download). */
    fun offlineVoice(ctx: Context) = p(ctx).getBoolean("offline_voice", true)
    fun setOfflineVoice(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("offline_voice", v).apply()

    /** false = small Qwen2.5-0.5B (fast); true = Qwen2.5-1.5B (better, slower, 3x bigger). */
    fun bigBrain(ctx: Context) = p(ctx).getBoolean("big_brain", false)
    fun setBigBrain(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("big_brain", v).apply()
}
