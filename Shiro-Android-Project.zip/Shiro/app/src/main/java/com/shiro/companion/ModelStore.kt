package com.shiro.companion

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class DownloadCancelled : IOException("Download cancelled")
class HttpStatusException(val code: Int) : IOException("The server answered HTTP $code")

object ModelStore {
    // Brain: Qwen2.5-1.5B-Instruct (Apache-2.0), MediaPipe .task bundle with a 4096-token context
    const val LLM_URL =
        "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.task"
    // Ears: multilingual Whisper base (MIT) in sherpa-onnx format
    const val WHISPER_URL =
        "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-base.tar.bz2"
    // Voices
    const val PIPER_BASE = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/"
    const val MMS_BASE = "https://huggingface.co/willwade/mms-tts-multilingual-models-onnx/resolve/main/"

    const val CORE_MB = 1850
    private const val LLM_MIN_BYTES = 500_000_000L

    fun root(ctx: Context): File = File(ctx.filesDir, "models").also { it.mkdirs() }
    fun llmFile(ctx: Context) = File(root(ctx), "qwen.task")
    fun whisperDir(ctx: Context) = File(root(ctx), "whisper-multi")
    fun voiceDir(ctx: Context, v: VoiceSpec) = File(root(ctx), v.id)

    fun coreReady(ctx: Context): Boolean =
        llmFile(ctx).let { it.exists() && it.length() > LLM_MIN_BYTES } &&
            File(whisperDir(ctx), ".ok").exists()

    fun voiceReady(ctx: Context, v: VoiceSpec): Boolean = File(voiceDir(ctx, v), ".ok").exists()

    fun ready(ctx: Context, lang: Lang) = coreReady(ctx) && voiceReady(ctx, lang.voice)

    fun missingMb(ctx: Context, lang: Lang): Int =
        (if (coreReady(ctx)) 0 else CORE_MB) + (if (voiceReady(ctx, lang.voice)) 0 else lang.voice.approxMb)

    fun deleteCore(ctx: Context) {
        llmFile(ctx).delete()
        File(root(ctx), "qwen.task.part").delete()
        whisperDir(ctx).deleteRecursively()
    }

    fun deleteVoice(ctx: Context, v: VoiceSpec) {
        voiceDir(ctx, v).deleteRecursively()
    }

    fun downloadCore(ctx: Context, cancelled: () -> Boolean, onProgress: (String, Int) -> Unit) {
        val root = root(ctx)
        needSpace(root, 2_600_000_000L)
        if (!(llmFile(ctx).exists() && llmFile(ctx).length() > LLM_MIN_BYTES)) {
            val part = File(root, "qwen.task.part")
            downloadWithRetry(LLM_URL, part, cancelled) { onProgress(Tr.t("Shiro's brain"), it) }
            llmFile(ctx).delete()
            if (!part.renameTo(llmFile(ctx))) throw IOException(Tr.t("Could not save the brain file."))
        }
        if (!File(whisperDir(ctx), ".ok").exists()) {
            val tar = File(root, "whisper.tar.bz2.part")
            downloadWithRetry(WHISPER_URL, tar, cancelled) { onProgress(Tr.t("Shiro's ears"), it) }
            onProgress(Tr.t("Unpacking Shiro's ears"), 100)
            // keep only int8 models (smaller); skip the full-precision copies
            unpack(tar, whisperDir(ctx)) { name -> !name.endsWith(".onnx") || name.contains("int8") }
            tar.delete()
        }
    }

    fun downloadVoice(ctx: Context, v: VoiceSpec, cancelled: () -> Boolean, onProgress: (String, Int) -> Unit) {
        val root = root(ctx)
        needSpace(root, 700_000_000L)
        val dir = voiceDir(ctx, v)
        when (v) {
            is VoiceSpec.Piper -> {
                val tar = File(root, "${v.id}.tar.bz2.part")
                downloadWithRetry("$PIPER_BASE${v.pack}.tar.bz2", tar, cancelled) { onProgress(Tr.t("Shiro's voice"), it) }
                onProgress(Tr.t("Unpacking Shiro's voice"), 100)
                unpack(tar, dir) { true }
                tar.delete()
                if (dir.listFiles { f -> f.name.endsWith(".onnx") }.isNullOrEmpty() ||
                    !File(dir, "tokens.txt").exists()
                ) {
                    dir.deleteRecursively()
                    throw IOException(Tr.t("The voice pack looks incomplete. Please try again."))
                }
            }
            is VoiceSpec.Mms -> {
                dir.deleteRecursively(); dir.mkdirs()
                val tokens = File(dir, "tokens.txt.part")
                downloadWithRetry("$MMS_BASE${v.iso3}/tokens.txt", tokens, cancelled) { }
                val model = File(dir, "model.onnx.part")
                downloadWithRetry("$MMS_BASE${v.iso3}/model.onnx", model, cancelled) { onProgress(Tr.t("Shiro's voice"), it) }
                if (!tokens.renameTo(File(dir, "tokens.txt")) || !model.renameTo(File(dir, "model.onnx"))) {
                    throw IOException(Tr.t("Could not save the voice files."))
                }
            }
        }
        File(dir, ".ok").writeText("ok")
    }

    private fun needSpace(root: File, bytes: Long) {
        if (root.usableSpace < bytes) throw IOException(Tr.t("Not enough free storage on this phone."))
    }

    private fun downloadWithRetry(url: String, dest: File, cancelled: () -> Boolean, onPercent: (Int) -> Unit) {
        var attempt = 0
        while (true) {
            if (cancelled()) throw DownloadCancelled()
            try {
                download(url, dest, cancelled, onPercent)
                return
            } catch (e: DownloadCancelled) {
                throw e
            } catch (e: HttpStatusException) {
                if (e.code == 404 || e.code == 403 || e.code == 401) {
                    dest.delete()
                    throw IOException(Tr.f("This download is not available right now (HTTP %d).", e.code))
                }
                if (++attempt >= 6) throw IOException(Tr.f("The download server is busy (HTTP %d). Please try again later.", e.code))
                sleepBackoff(attempt, cancelled)
            } catch (e: IOException) {
                if (++attempt >= 6) throw IOException(Tr.t("The connection keeps dropping. Please check your internet and tap again; the download will continue where it stopped."))
                sleepBackoff(attempt, cancelled)
            }
        }
    }

    private fun sleepBackoff(attempt: Int, cancelled: () -> Boolean) {
        var ms = 1500L * attempt
        while (ms > 0 && !cancelled()) { Thread.sleep(250); ms -= 250 }
    }

    private fun download(url: String, dest: File, cancelled: () -> Boolean, onPercent: (Int) -> Unit) {
        var offset = if (dest.exists()) dest.length() else 0L
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 20_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "ShiroApp/1.0 (Android)")
            if (offset > 0) conn.setRequestProperty("Range", "bytes=$offset-")
            val code = conn.responseCode
            if (code == 416) { onPercent(100); return } // already complete
            if (code != 200 && code != 206) throw HttpStatusException(code)
            val append = code == 206
            if (!append) offset = 0L
            val len = conn.contentLengthLong
            val total = if (len > 0) len + offset else -1L
            FileOutputStream(dest, append).use { out ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    var done = offset
                    var last = -1
                    while (true) {
                        if (cancelled()) throw DownloadCancelled()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != last) { last = pct; onPercent(pct) }
                        }
                    }
                }
            }
            if (total > 0 && dest.length() != total) throw IOException("Incomplete download")
            onPercent(100)
        } finally {
            conn.disconnect()
        }
    }

    private fun unpack(archive: File, target: File, keep: (String) -> Boolean) {
        target.deleteRecursively()
        target.mkdirs()
        val canonicalTarget = target.canonicalPath + File.separator
        TarArchiveInputStream(
            BZip2CompressorInputStream(BufferedInputStream(FileInputStream(archive), 1 shl 16))
        ).use { tar ->
            while (true) {
                val entry = tar.nextTarEntry ?: break
                val name = entry.name.substringAfter('/', "")
                if (name.isEmpty() || !keep(name.substringAfterLast('/'))) {
                    if (!entry.isDirectory || name.isEmpty()) continue
                }
                val outFile = File(target, name)
                if (!outFile.canonicalPath.startsWith(canonicalTarget)) continue // path-traversal guard
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { o -> tar.copyTo(o) }
                }
            }
        }
        File(target, ".ok").writeText("ok")
    }
}
