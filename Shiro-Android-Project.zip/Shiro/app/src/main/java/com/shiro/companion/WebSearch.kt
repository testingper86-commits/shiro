package com.shiro.companion

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Internet lookup used only when the user explicitly asks for it.
 * Sources: DuckDuckGo HTML results (no account or key), then Wikipedia as a fallback.
 * Only the words of the search query are sent.
 */
object WebSearch {
    data class Result(val title: String, val snippet: String)

    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    fun isOnline(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Blocking. Throws IOException when there is no usable connection at all. */
    fun search(query: String, langCode: String): List<Result> {
        val q = query.trim().take(200)
        var ioError: IOException? = null
        try {
            val html = get("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"), langCode)
            val r = parseDuckDuckGo(html)
            if (r.isNotEmpty()) return r
        } catch (e: IOException) {
            ioError = e
        }
        try {
            val url = "https://$langCode.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=" +
                URLEncoder.encode(q, "UTF-8") +
                "&gsrlimit=3&prop=extracts&exintro=1&explaintext=1&exchars=500&format=json&redirects=1"
            val r = parseWikipedia(get(url, langCode))
            if (r.isNotEmpty()) return r
            ioError = null
        } catch (e: IOException) {
            if (ioError == null) ioError = e
        }
        if (ioError != null) throw ioError
        return emptyList()
    }

    private fun get(url: String, langCode: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8_000
            conn.readTimeout = 10_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept-Language", "$langCode,en;q=0.7")
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val out = ByteArrayOutputStream()
            conn.inputStream.use { input ->
                val buf = ByteArray(16 * 1024)
                var total = 0
                while (total < 1_500_000) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n); total += n
                }
            }
            return out.toString("UTF-8")
        } finally {
            conn.disconnect()
        }
    }

    // ---- pure parsing (unit-tested) ----

    private val ddgTitle = Regex("""<a[^>]*class="[^"]*result__a[^"]*"[^>]*>(.*?)</a>""", setOf(RegexOption.DOT_MATCHES_ALL))
    private val ddgSnippet = Regex(
        """<(?:a|td|div)[^>]*class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</(?:a|td|div)>""",
        setOf(RegexOption.DOT_MATCHES_ALL)
    )
    private val tags = Regex("""<[^>]+>""")
    private val spaces = Regex("""\s+""")

    private val ddgBlock = Regex("""<div[^>]*class="[^"]*\bresult\b[^"]*"[^>]*>""")

    fun parseDuckDuckGo(html: String): List<Result> {
        // 1) per result block, so ads and snippet-less results cannot shift the pairing
        val starts = ddgBlock.findAll(html).map { it.range.first }.toList()
        val out = ArrayList<Result>()
        for ((i, st) in starts.withIndex()) {
            val block = html.substring(st, if (i + 1 < starts.size) starts[i + 1] else html.length)
            if (block.contains("result--ad")) continue
            val title = ddgTitle.find(block)?.let { clean(it.groupValues[1]) } ?: continue
            val snip = ddgSnippet.find(block)?.let { clean(it.groupValues[1]) } ?: continue
            if (title.isNotEmpty() && snip.isNotEmpty()) out.add(Result(title.take(90), snip.take(240)))
            if (out.size == 4) break
        }
        if (out.isNotEmpty()) return out
        // 2) fallback: pair titles and snippets by order
        val titles = ddgTitle.findAll(html).map { clean(it.groupValues[1]) }.toList()
        val snippets = ddgSnippet.findAll(html).map { clean(it.groupValues[1]) }.toList()
        for (i in titles.indices) {
            val sn = snippets.getOrNull(i).orEmpty()
            if (titles[i].isNotEmpty() && sn.isNotEmpty()) out.add(Result(titles[i].take(90), sn.take(240)))
            if (out.size == 4) break
        }
        return out
    }

    fun parseWikipedia(json: String): List<Result> {
        val pages = JSONObject(json).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val list = ArrayList<Triple<Int, String, String>>()
        for (key in pages.keys()) {
            val p = pages.getJSONObject(key)
            val extract = p.optString("extract").trim()
            if (extract.isNotEmpty()) list.add(Triple(p.optInt("index", 99), p.optString("title"), extract))
        }
        return list.sortedBy { it.first }.take(3).map { Result(it.second.take(90), it.third.take(300)) }
    }

    fun clean(s: String): String {
        var t = tags.replace(s, " ")
        t = t.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
            .replace("&#x27;", "'").replace("&#39;", "'").replace("&nbsp;", " ")
        t = Regex("""&#(\d+);""").replace(t) { m -> m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it)) } ?: " " }
        return spaces.replace(t, " ").trim()
    }

    fun formatForPrompt(results: List<Result>): String =
        results.mapIndexed { i, r -> "[${i + 1}] ${r.title}: ${r.snippet}" }.joinToString("\n")
}
