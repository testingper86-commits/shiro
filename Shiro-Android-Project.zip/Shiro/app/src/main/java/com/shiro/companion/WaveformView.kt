package com.shiro.companion

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Animated bar waveform. Fed by the microphone level, or self-animated while Shiro speaks. */
class WaveformView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val bars = 27
    @Volatile private var level = 0f
    @Volatile var synthetic = false
    private var smooth = 0f

    fun setLevel(v: Float) { level = v.coerceIn(0f, 1f) }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        paint.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, intArrayOf(0xFF2D9CFF.toInt(), 0xFF8A5CF6.toInt(), 0xFFFF7AC8.toInt()), null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val t = System.currentTimeMillis() / 160.0
        val target = if (synthetic) 0.45f + 0.35f * abs(sin(t * 0.7)).toFloat() else level
        smooth += (target - smooth) * 0.25f
        val w = width.toFloat(); val h = height.toFloat()
        val slot = w / bars
        for (i in 0 until bars) {
            val centre = 1f - abs(i - bars / 2f) / (bars / 2f)           // taller in the middle
            val wobble = 0.5f + 0.5f * sin(t + i * 0.9).toFloat()
            val barH = (h * (0.08f + 0.92f * smooth * centre * (0.4f + 0.6f * wobble))).coerceAtLeast(h * 0.06f)
            val x = i * slot + slot * 0.2f
            rect.set(x, (h - barH) / 2f, x + slot * 0.6f, (h + barH) / 2f)
            c.drawRoundRect(rect, slot * 0.3f, slot * 0.3f, paint)
        }
        postInvalidateOnAnimation()
    }
}
