package com.shiro.companion

/**
 * Warm, pre-written replies for common feelings. Instant, predictable and safe; the AI is used for everything else.
 * Only short messages that clearly name a feeling are answered here, and never when a crisis phrase was found.
 * Texts must be reviewed by a mental-health professional and native speakers before public release.
 */
object SupportReplies {
    private class Topic(val en: Regex, val hi: Regex, val enReplies: List<String>, val hiReplies: List<String>)

    private val ic = RegexOption.IGNORE_CASE
    private val negation = Regex("""\b(not|isn't|aren't|wasn't|never|no longer)\s+(feeling\s+)?(sad|anxious|stressed|lonely|angry|tired|depressed|worried)\b""", ic)
    private var counter = 0

    private val topics = listOf(
        Topic(
            Regex("""passed away|lost my (brother|sister|mother|mom|father|dad|friend|son|daughter|husband|wife|grandmother|grandfather)|\bgrie(f|ving)\b|miss (him|her|them) so|my (brother|sister|mother|mom|father|dad|friend) died""", ic),
            Regex("""गुज़र|गुजर|निधन|को खो दिया"""),
            listOf(
                "I'm so sorry for your loss. Grief can feel unbearable, and there is no right way to carry it. I'm here with you. Would you like to tell me about them?",
                "That is such a painful thing to go through. I'm really sorry. You don't have to be strong for me. What do you miss most about them?",
                "Losing someone you love hurts deeply. Thank you for trusting me with this. How are you holding up today?"
            ),
            listOf(
                "आपके नुकसान के लिए मुझे बहुत अफ़सोस है। ग़म सहना बहुत भारी होता है, और इसे सहने का कोई सही तरीका नहीं है। मैं आपके साथ हूँ। क्या आप उनके बारे में बताना चाहेंगे?",
                "यह बहुत दर्द भरा समय है। मुझे सच में अफ़सोस है। आपको मेरे सामने मज़बूत बनने की ज़रूरत नहीं है। आपको उनकी सबसे ज़्यादा क्या बात याद आती है?",
                "किसी अपने को खो देना गहरा दर्द देता है। मुझ पर भरोसा करने के लिए शुक्रिया। आज आप कैसे हैं?"
            )
        ),
        Topic(
            Regex("""\b(hopeless|worthless|useless)\b|feel empty|feeling empty""", ic),
            Regex("""बेकार|निराश|हताश|उम्मीद नहीं"""),
            listOf(
                "That sounds really heavy, and I'm glad you said it out loud. You matter. If it ever feels like too much, you can tap Need help on your screen at any time. What is making it feel this way?",
                "I'm sorry it feels like this. You are worth caring about. If it becomes too much, please reach out to someone you trust or tap Need help. Would you like to tell me more?",
                "Those are painful feelings to carry. I'm here with you. There are people who want to help too, and the Need help button is always on your screen. What has been going on?"
            ),
            listOf(
                "यह बहुत भारी लगता है, और आपने इसे कह दिया, यह अच्छा है। आप मायने रखते हैं। अगर कभी यह बहुत ज़्यादा लगे, तो स्क्रीन पर मदद चाहिए दबा सकते हैं। यह एहसास किस वजह से है?",
                "मुझे अफ़सोस है कि ऐसा लग रहा है। आप परवाह के क़ाबिल हैं। अगर यह बहुत ज़्यादा हो जाए, तो किसी भरोसेमंद से बात करें या मदद चाहिए दबाएँ। क्या आप और बताएँगे?",
                "ये दर्द भरी भावनाएँ हैं। मैं आपके साथ हूँ। कुछ लोग मदद करना चाहते हैं, और मदद चाहिए बटन हमेशा स्क्रीन पर है। क्या चल रहा है?"
            )
        ),
        Topic(
            Regex("""\blonely\b|\bso alone\b|no one (cares|understands|to talk)|nobody (cares|understands|to talk)|\bisolated\b""", ic),
            Regex("""अकेला|अकेली|अकेलापन"""),
            listOf(
                "Feeling alone is really hard, and I'm glad you told me. I'm here and I'm listening. What has today been like for you?",
                "I'm sorry you're feeling so alone. You matter, and you don't have to go through this by yourself right now. Would you like to tell me more?",
                "That sounds lonely. Thank you for sharing it with me. Is there someone you trust you could reach out to, or shall we just talk for a while?"
            ),
            listOf(
                "अकेलापन बहुत मुश्किल होता है, और आपने मुझे बताया, यह अच्छा लगा। मैं यहाँ हूँ और सुन रही हूँ। आज का दिन कैसा रहा?",
                "मुझे अफ़सोस है कि आप इतना अकेला महसूस कर रहे हैं। आप मायने रखते हैं, और अभी आपको यह अकेले नहीं सहना है। क्या आप थोड़ा और बताएँगे?",
                "यह अकेलापन भरा लगता है। मुझसे साझा करने के लिए शुक्रिया। क्या कोई भरोसेमंद है जिससे आप बात कर सकें, या हम थोड़ी देर यूँ ही बात करें?"
            )
        ),
        Topic(
            Regex("""\banxious\b|\banxiety\b|\bstressed\b|\bstress\b|\bworried\b|\bpanic\b|\bnervous\b|\boverwhelmed\b|\bscared\b""", ic),
            Regex("""तनाव|चिंता|घबराहट|घबरा|डर लग|बेचैन"""),
            listOf(
                "That sounds really stressful. Let's slow down together. Take one slow breath with me. What is weighing on you most right now?",
                "I hear how worried you are. Your feelings make sense. Would it help to tell me what's going on, one piece at a time?",
                "It's hard to feel overwhelmed. You're not alone in this moment. What is the biggest thing on your mind?"
            ),
            listOf(
                "यह सच में तनाव भरा लगता है। चलिए साथ में धीमे हो जाते हैं। मेरे साथ एक धीमी साँस लीजिए। अभी सबसे ज़्यादा किस बात का बोझ है?",
                "मैं समझ रही हूँ कि आप कितने चिंतित हैं। आपकी भावनाएँ जायज़ हैं। क्या आप एक-एक करके बताना चाहेंगे कि क्या हो रहा है?",
                "घबराहट में होना मुश्किल है। इस पल में आप अकेले नहीं हैं। आपके मन में सबसे बड़ी बात क्या है?"
            )
        ),
        Topic(
            Regex("""\bsad\b|\bdepressed\b|\bunhappy\b|feeling low|feel low|\bcrying\b|want to cry""", ic),
            Regex("""उदास|दुखी|रोना|रोने|अच्छा नहीं लग"""),
            listOf(
                "I'm sorry you're feeling this way. It's okay to feel sad, and you don't have to hide it here. Would you like to tell me what's been happening?",
                "That sounds really heavy. I'm here and I'm not going anywhere. What has been hardest lately?",
                "Thank you for telling me how you feel. Your feelings are valid. Do you want to talk about what's behind it?"
            ),
            listOf(
                "मुझे अफ़सोस है कि आप ऐसा महसूस कर रहे हैं। उदास होना ठीक है, और यहाँ आपको इसे छिपाने की ज़रूरत नहीं। क्या आप बताना चाहेंगे कि क्या हुआ है?",
                "यह बहुत भारी लगता है। मैं यहाँ हूँ और कहीं नहीं जा रही। हाल में सबसे मुश्किल क्या रहा है?",
                "अपना हाल बताने के लिए शुक्रिया। आपकी भावनाएँ जायज़ हैं। क्या आप उसके पीछे की बात करना चाहेंगे?"
            )
        ),
        Topic(
            Regex("""can'?t sleep|cannot sleep|insomnia|\bexhausted\b|so tired|\btired\b""", ic),
            Regex("""नींद नहीं|थक|थकान"""),
            listOf(
                "That sounds exhausting. Your body and mind may need rest. Would you like to try a slow breathing exercise, or just talk for a bit?",
                "I'm sorry you're so worn out. Being tired makes everything feel heavier. What has been keeping you up or draining you?",
                "Rest matters a lot. You can try the Sleep Support sounds in the Wellness tab. What's on your mind right now?"
            ),
            listOf(
                "यह थकाने वाला लगता है। आपके शरीर और मन को आराम चाहिए। क्या आप धीमी साँस वाला अभ्यास करना चाहेंगे, या बस थोड़ी बात करें?",
                "मुझे अफ़सोस है कि आप इतना थक गए हैं। थकान में सब कुछ भारी लगता है। आपको क्या जगाए रख रहा है या थका रहा है?",
                "आराम बहुत ज़रूरी है। आप सेहत टैब में नींद में मदद वाली आवाज़ें सुन सकते हैं। अभी आपके मन में क्या है?"
            )
        ),
        Topic(
            Regex("""\bangry\b|\bfurious\b|\bfrustrated\b|\bannoyed\b""", ic),
            Regex("""गुस्सा|ग़ुस्सा|चिढ़|झुंझला"""),
            listOf(
                "It sounds like you're really frustrated. That's allowed. What happened?",
                "I hear the anger in that. It makes sense to feel this way sometimes. Do you want to tell me what set it off?",
                "Anger often shows something matters to you. I'm listening. What's going on?"
            ),
            listOf(
                "लगता है आप बहुत नाराज़ हैं। यह स्वाभाविक है। क्या हुआ?",
                "मैं उस ग़ुस्से को सुन रही हूँ। कभी-कभी ऐसा लगना ठीक है। क्या आप बताएँगे कि किस बात से शुरू हुआ?",
                "ग़ुस्सा अक्सर बताता है कि कोई बात आपके लिए मायने रखती है। मैं सुन रही हूँ। क्या चल रहा है?"
            )
        )
    )

    /** Returns a pre-written reply, or null so the AI answers. Call only when no crisis phrase was found. */
    fun match(text: String, langCode: String): String? {
        if (langCode != "en" && langCode != "hi") return null
        val t = Safety.normalize(text).trim()
        if (t.isEmpty() || t.contains('?') || t.split(Regex("""\s+""")).size > 14) return null
        if (negation.containsMatchIn(t)) return null
        val hindi = langCode == "hi"
        val topic = topics.firstOrNull { if (hindi) it.hi.containsMatchIn(t) else it.en.containsMatchIn(t) } ?: return null
        val list = if (hindi) topic.hiReplies else topic.enReplies
        return list[(counter++) % list.size]
    }
}
