plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shiro.companion"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.shiro.companion"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    val keystorePath: String? = System.getenv("SHIRO_KEYSTORE_PATH")
    val haveKey = keystorePath != null && File(keystorePath).exists()
    signingConfigs {
        if (haveKey) create("release") {
            storeFile = File(keystorePath!!)
            storePassword = System.getenv("SHIRO_KEYSTORE_PASSWORD")
            keyAlias = System.getenv("SHIRO_KEY_ALIAS")
            keyPassword = System.getenv("SHIRO_KEY_PASSWORD")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Your own release key when the GitHub secrets exist, otherwise the debug key (installs fine for testing).
            signingConfig = if (haveKey) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    testOptions { unitTests.isReturnDefaultValues = true }

    packaging {
        jniLibs { pickFirsts += listOf("**/libc++_shared.so") }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    // Whisper speech-to-text + Kokoro text-to-speech (sherpa-onnx, Apache-2.0)
    implementation(files("libs/sherpa-onnx-1.13.8.aar"))
    // On-device LLM runtime (Apache-2.0) running Qwen2.5 .task file
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    // tar.bz2 extraction of downloaded voice models
    implementation("org.apache.commons:commons-compress:1.26.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
}
