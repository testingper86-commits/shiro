# Shiro - voice companion (Android)

Screens follow the supplied "MindfulAI" mockup (splash, home, listening, captions, wellness, mood tracker, growth, settings) but the app name stays **Shiro** and the logo is the white cat. Backgrounds are gradients (the mockup's landscape artwork is not reproduced); icons are emoji/text glyphs.


Voice only: tap Shiro, talk, Shiro answers out loud. No chat screen.
All parts are open source: Whisper (listening), Piper / Meta-MMS voices (speaking), Qwen2.5-1.5B (thinking),
all run on the phone through sherpa-onnx and MediaPipe. Internet is used only to download models once
and when you ask Shiro to search (DuckDuckGo, Wikipedia fallback).

## Get the APK
1. Push this folder to a GitHub repo (keep .github/workflows/build.yml).
2. Actions > "Build Shiro APK" > latest run > artifact `Shiro-APK`. Install the .apk on the phone.
3. Check the run summary: it lists every model download link and its HTTP status, and unit-test results.
4. First launch: tap Download (brain + ears + the voice of the chosen language), then tap Shiro.

## Languages (18)
English, Hindi, Spanish, French, Italian, Portuguese, German, Russian, Arabic, Turkish, Vietnamese,
Indonesian, Polish, Urdu (Piper voices, per-voice licences) and Kannada, Tamil, Telugu, Bengali (Meta MMS-TTS,
licence CC-BY-NC 4.0: NON-COMMERCIAL ONLY). Each voice (~80-115 MB) downloads when first selected.
The small AI is weak in Hindi, Urdu, Polish, Kannada, Tamil, Telugu and Bengali; the app tells the user.
Whisper "base" recognises Indian languages poorly; a larger Whisper model would help but is ~1 GB.

## Internet search
Only on explicit requests ("search for...", weather, news...) and never for sentences about feelings.
First use asks for consent; the Internet button turns it on/off. Needs `html.duckduckgo.com` not to block the user.

## Safety
Crisis phrases in all 18 languages skip the AI, speak a caring scripted reply and open worldwide helplines
(201 countries and territories, Helplines.kt, from Wikipedia, retrieved 2026-10-22: re-check before each release).
Crisis phrase lists and non-English texts are not reviewed by native speakers.

## Needs
Android 8+, 64-bit ARM, ~6 GB RAM recommended, ~3 GB free storage. Signed with the debug key (installable, not Play-ready).

## What the extra screens really do
Breathing, meditation, quick relief: guided on-screen steps with an animated circle (English text, no speech). Relaxing sounds / sleep: rain, ocean, wind synthesised on the phone, sleep timer; the screen must stay on (sounds stop if the app is backgrounded). Mood: stored on the phone, 7-day chart. Journal/gratitude: spoken notes transcribed on the phone. Goals, trusted contacts, progress: stored locally. Notifications: not available in this version.

## Also in this build
Daily gentle reminder (off / 9:00 / 20:00, shown in the chosen language) and relaxing/sleep sounds that keep playing with the screen off (foreground service; Stop button in the notification). French Polynesia has no entry because its source row was ambiguous; it gets findahelpline.com. Malawi's listed numbers are mobile-network numbers and a second source says there is no dedicated line there.

## Hindi
When the language is Hindi, the app's own screens, buttons and dialogs are in Hindi too (Tr.kt). Other languages still show English screens. The app name stays "Shiro".

## Speed and download size
Default: open-source Offline voices (Whisper for listening, Piper/MMS for speaking, everything stays on the phone) plus the small 0.5 GB brain: first download about 0.8 GB. In Settings you can switch to Phone voice (the phone's own speech service, almost no download; may send audio to Google on some phones) and to the larger 1.5 GB brain (better replies, slower). Speaking is gap-free: the next sentence is prepared while the current one plays.

## Look
The landscape artwork (sunset lake, mountains, pines) is generated, not photographed, and is used on the splash screen, as a soft background, and on the Wellness and Growth picture cards. Dialogs use a dark rounded theme. The cat logo has no background box and sits in a glowing orb; the app icon is an adaptive icon.
